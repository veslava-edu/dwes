Vamos a desgranar uno de los conceptos más cruciales que te encontrarás en tu carrera: el patrón **Modelo-Vista-Controlador (MVC)** en PHP. Olvida todo lo que crees que sabes sobre organizar código; estamos a punto de entrar en una nueva dimensión de orden y eficiencia, como pasar de jugar al Tetris a diseñar los planos de un rascacielos.

Coge tu café, abre tu editor de código y prepárate, porque lo que vamos a ver hoy es el pan de cada día en el 99% de las aplicaciones web profesionales. ¡Empezamos!

<!-- Tema: PHP - MVC -->
# PHP - Modelo-Vista-Controlador (MVC)

Imagina que quieres montar el restaurante más exitoso de la ciudad. No pondrías al chef a tomar las comandas, ni al camarero a fregar los platos, ¿verdad? Sería un caos. Cada persona tiene su especialidad y su lugar. El chef (el **Modelo**) es el maestro de los datos y la lógica, sabe cómo preparar cada plato a la perfección. El camarero (el **Controlador**) es el intermediario, toma las peticiones del cliente y se comunica con la cocina. Y finalmente, la presentación del plato y la decoración del local (la **Vista**) es lo que el cliente ve y con lo que interactúa.

En el desarrollo web, durante mucho tiempo, programábamos como si el chef, el camarero y el decorador fueran la misma persona. El resultado era lo que llamamos "código espagueti": un lío de HTML, lógica de negocio y consultas a la base de datos, todo en el mismo archivo. Cambiar el color de un botón podía, por arte de magia negra, romper la forma en que se calculaban los precios.

El patrón **MVC** viene a poner orden en este caos. Es una filosofía, un **patrón de arquitectura de software** que nos obliga a separar nuestra aplicación en esas tres partes especializadas: Modelo, Vista y Controlador. Al igual que en nuestro restaurante, cada componente tiene una única responsabilidad, haciendo que nuestra aplicación sea más organizada, más fácil de mantener y, sobre todo, más escalable. ¡Es la receta secreta para no volverte loco en proyectos grandes!

## Patrones de Diseño

Antes de meternos de lleno con el MVC, tenemos que entender de dónde viene. El MVC es un tipo de **patrón de diseño**.

!!! note "Definición: Patrón de Diseño"
    Un patrón de diseño es como una receta de cocina probada y perfeccionada por miles de chefs antes que tú. No es un trozo de código que copias y pegas, sino una **solución general y reutilizable a un problema común** en el diseño de software. Te dan un esquema, una estrategia probada para resolver problemas recurrentes, mejorando la calidad y flexibilidad de tu código.

<div class="center"><img src="../images/patrones.png" alt="Patrones de diseño" /></div>


Los patrones son el destilado de años de experiencia de la comunidad de desarrolladores. Se clasifican en varias categorías, cada una enfocada en un tipo de problema:

| Categoría | Propósito | Ejemplo del mundo real |
| --- | --- | --- |
| **Creacionales** | Se centran en cómo se crean los objetos, dándote flexibilidad en el proceso. | Como una máquina de vending: tú pides "refresco", y ella se encarga de crear y darte una Coca-Cola, sin que sepas los detalles internos. |
| **Estructurales** | Se ocupan de cómo se componen las clases y los objetos para formar estructuras más grandes y flexibles. | Como un adaptador de enchufe universal: te permite conectar tu dispositivo (que tiene una estructura) a un enchufe de pared (con otra estructura), aunque sean incompatibles. |
| **De Comportamiento** | Se centran en la comunicación e interacción entre objetos, definiendo cómo colaboran. | Como la suscripción a un canal de YouTube: cuando el YouTuber (sujeto) sube un vídeo nuevo, notifica automáticamente a todos sus suscriptores (observadores). |

El patrón MVC, en concreto, es un **patrón arquitectónico**, ya que define la estructura a gran escala de todo nuestro sistema.

!!! tip inline end "Refactoring Guru"
    Uno de los mejores sitios para aprender sobre patrones de diseño, con explicaciones visuales y ejemplos de código en múltiples lenguajes, es [Refactoring Guru](https://refactoring.guru/es/design-patterns). ¡Guárdalo en tus favoritos!



!!! question "Reflexiona"
    1. Piensa en el sistema de "login con Google/Facebook" que ves en muchas webs. ¿Qué tipo de patrón crees que podría estar implicado para manejar diferentes proveedores de autenticación de una manera unificada?
    2. Cuando usas un framework como Laravel o Symfony, no creas los objetos principales directamente, sino que pides al framework que te los dé (por ejemplo, el objeto `Request`). ¿Qué categoría de patrón te recuerda esto?
    3. ¿Por qué crees que se insiste tanto en "soluciones probadas"? ¿Qué riesgos corres al inventar tu propia "solución" desde cero para un problema común?

<br/><hr/>

## Arquitecturas de Software

Si los patrones de diseño son recetas, la **arquitectura de software** es el plano completo de la cocina de nuestro restaurante. Define la estructura fundamental de todo el sistema: cómo se dividen, organizan y comunican los grandes componentes.

!!! note "Definición: Arquitectura de Software"
    Es el conjunto de estructuras de alto nivel de un sistema de software. Define los componentes principales, sus relaciones y las reglas que gobiernan su diseño y evolución. Es el "big picture", la decisión más importante y difícil de cambiar en un proyecto.



<div class="center"><img src="../images/arquitecturas.png" alt="Arquitecturas software" /></div>


En el desarrollo backend, han evolucionado varias arquitecturas principales a lo largo del tiempo.

```markmap
# Arquitecturas Backend

## Monolítica
- Todo en un solo bloque
- **Pros**:
  - Simple de empezar
  - Fácil de desplegar (al principio)
- **Contras**:
  - Difícil de escalar
  - "Big Ball of Mud" (Bola de lodo)
  - Un fallo puede tumbar todo

## Capas (N-Layer)
- Separación por función (Presentación, Negocio, Datos)
- **Pros**:
  - Modularidad
  - Mantenimiento más sencillo
- **Contras**:
  - Puede ser rígida

## Microservicios
- Evolución de los servicios
- Colección de pequeños servicios autónomos
- **Pros**:
  - Escalabilidad granular
  - Equipos independientes
  - Flexibilidad tecnológica
- **Contras**:
  - Complejidad operacional
  - Gestión de datos distribuida
```

| Arquitectura | Analogía | Ideal para... |
| :--- | :--- | :--- |
| **Monolítica** | Un robot de cocina "todo en uno". Bate, pica, amasa... todo en el mismo cacharro. | Proyectos pequeños, prototipos, MVPs (Minimum Viable Products). Cuando la velocidad de desarrollo inicial es clave. |
| **Capas** | Una cadena de montaje. Cada estación tiene una tarea específica y pasa el producto a la siguiente. | Aplicaciones empresariales estándar donde la estructura y la separación de responsabilidades son importantes. |
| **Microservicios** | Un centro comercial. Cada tienda es independiente, tiene su propio stock y personal, pero todas colaboran para ofrecer una experiencia completa al cliente. | Grandes plataformas como Netflix, Amazon, Spotify. Sistemas complejos que requieren alta escalabilidad y agilidad. |

### Ejemplo Práctico: Netflix

La arquitectura de Netflix es el ejemplo paradigmático de **microservicios**. No tienen una gigantesca aplicación "Netflix". Tienen cientos de pequeños servicios que se comunican entre sí. Hay un servicio para gestionar el catálogo de películas, otro para las cuentas de usuario, otro para las recomendaciones, otro para el streaming de vídeo, etc.

!!! info "Ventaja Competitiva"
    Esta arquitectura les permite que un equipo en California pueda actualizar el algoritmo de recomendación sin afectar al equipo de Ámsterdam que está optimizando la compresión de vídeo. Si el servicio de recomendaciones falla, puedes seguir viendo tu serie, aunque no te aparezcan sugerencias nuevas.

!!! question "Reflexiona"
    1. Una tienda online pequeña (un e-commerce para una pastelería local). ¿Qué arquitectura elegirías y por qué?
    2. La aplicación de gestión académica de la universidad (matrículas, notas, horarios). ¿Qué arquitectura te parece más sensata?
    3. Si tuvieras que construir una aplicación como Twitter, ¿qué problemas te encontrarías a largo plazo si eligieras una arquitectura monolítica?

<div class="center"><img src="../images/netflix.gif" alt="La arquitectura de Netflix" /></div>


<br/><hr/>

## Arquitectura de una Aplicación Web

Centrándonos en las aplicaciones web, es vital distinguir entre la organización física y la lógica de nuestra arquitectura. Suelen confundirse, pero son dos conceptos distintos.

### Capas Físicas (Tiers) vs. Capas Lógicas (Layers)

!!! note "Definición: Tier vs Layer"
    - **Tier (Capa Física):** Se refiere a una separación física, a hardware distinto. Un servidor web en una máquina y un servidor de base de datos en otra máquina constituyen una arquitectura de 2-tiers.
    - **Layer (Capa Lógica):** Se refiere a una separación conceptual dentro del código, a cómo organizas tus clases y módulos según su función (presentación, negocio, datos).

Puedes tener una arquitectura de 3 capas lógicas (presentación, negocio, datos) corriendo en una sola capa física (un único servidor). Esto es muy común en proyectos pequeños y medianos.

**Arquitectura 3-Tier (3 Capas Físicas)**

Es un estándar en la industria para aplicaciones robustas y seguras.

<div class="center"><img src="../images/tier3.png" alt="Arquitectura de tres capas físicas" /></div>

1.  **Servidor Web (Capa de Presentación):** Es la máquina que está de cara al público. Recibe las peticiones HTTP de los usuarios y ejecuta el código que genera el HTML.
2.  **Servidor de Aplicaciones (Capa de Lógica/Negocio):** Máquina interna donde reside la "magia". Aquí corre PHP, se ejecuta la lógica de negocio compleja, se toman decisiones. No es directamente accesible desde Internet.
3.  **Servidor de Base de Datos (Capa de Datos):** La máquina más protegida. Alberga la base de datos y solo acepta conexiones desde el servidor de aplicaciones.

```mermaid
graph TD
    subgraph "Internet (Público)"
        U[Usuario]
    end

    subgraph "DMZ (Zona Desmilitarizada)"
        FW1[Firewall]
        SW[Servidor Web - Tier 1]
    end

    subgraph "Red Interna (Privada)"
        FW2[Firewall]
        SA[Servidor de Aplicaciones - Tier 2]
        SBD[Servidor de Base de Datos - Tier 3]
    end

    U --> FW1 --> SW
    SW --> FW2 --> SA
    SA --> SBD
    SBD -- Datos --> SA
    SA -- Lógica procesada --> SW
    SW -- HTML/CSS/JS --> U
```

<div class="center"><img src="../images/tierlayer.png" alt="Arquitectura de tres capas lógicas" /></div>


!!! question "Reflexiona"
    1. ¿Qué ventajas de seguridad evidentes ofrece una arquitectura de 3-tiers frente a tenerlo todo en un solo servidor?
    2. Si tu aplicación web se vuelve extremadamente popular y el servidor empieza a ir lento, ¿qué capa (tier) sería la primera que necesitarías "escalar" (añadir más máquinas) y por qué?
    3. ¿Podrías tener una arquitectura de 3 capas lógicas (layers) en tu propio portátil usando XAMPP? Razona tu respuesta.

<br/><hr/>

## Modelo MVC

Y llegamos al corazón del tema. El patrón Modelo-Vista-Controlador (MVC) es una implementación específica y muy popular de una **arquitectura de 3 capas lógicas**. Es la forma estandarizada de organizar el código en la mayoría de aplicaciones web modernas.

### 4.1 - Componentes

![MVC](images/mvc.jpg){align=right & width=500}

El patrón divide la aplicación en tres componentes interconectados:

!!! note "Definición: Modelo"
    **El Cerebro y los Músculos.** Representa la información y las reglas de negocio de la aplicación. Es responsable de acceder y manipular los datos (normalmente de una base de datos). No tiene ni idea de cómo se van a mostrar esos datos. Su única preocupación es la integridad y la lógica de los datos. *Ejemplo en PHP: Una clase `UserModel.php` con métodos como `getUserById($id)` o `createUser($data)`.*

!!! note "Definición: Vista"
    **La Cara Bonita.** Es la responsable de la presentación de los datos. Es lo que el usuario ve en el navegador. Debería ser "tonta", es decir, contener la menor cantidad de lógica posible. Su trabajo es mostrar la información que le entrega el Controlador, usando HTML, CSS y JavaScript. *Ejemplo en PHP: Un archivo `user_profile_view.php` que contiene principalmente HTML y bucles `foreach` para mostrar datos.*

!!! note "Definición: Controlador"
    **El Director de Orquesta.** Actúa como el intermediario entre el Modelo y la Vista. Recibe las peticiones del usuario (por ejemplo, un clic en un enlace), decide qué hacer, pide al Modelo los datos necesarios, y luego le dice a la Vista cuál debe mostrarse con esos datos. Es el que gestiona el flujo de la aplicación. *Ejemplo en PHP: Una clase `UserController.php` con métodos como `showProfile($id)` o `registerUser()`.*

```mermaid
sequenceDiagram
    participant U as Usuario
    participant C as Controlador
    participant M as Modelo
    participant V as Vista

    U->>C: Petición HTTP (ej: /user/profile/123)
    C->>M: ¡Necesito los datos del usuario 123! (llama a getUserById(123))
    M->>M: Consulta la Base de Datos
    M-->>C: Aquí tienes los datos del usuario
    C->>V: ¡Muestra esta vista con estos datos! (carga la vista del perfil y le pasa los datos)
    V-->>U: Responde con el HTML generado
```

### 4.2 - Ventajas

Adoptar MVC no es un capricho, es una decisión estratégica que aporta enormes beneficios:

*   **Organización del código:** Adiós al "código espagueti". Cada cosa está en su sitio, facilitando la lectura y la comprensión del proyecto.
*   **Desarrollo en paralelo:** El equipo de *front-end* puede trabajar en las Vistas (HTML/CSS) al mismo tiempo que el equipo de *back-end* trabaja en los Modelos y Controladores (PHP/SQL), ya que las capas son independientes.
*   **Reutilización de código:** Un mismo Modelo puede ser utilizado por múltiples Controladores y Vistas. Por ejemplo, el modelo de usuario puede ser usado para mostrar el perfil, para el proceso de login o para un panel de administración.
*   **Mantenimiento sencillo:** Si necesitas cambiar cómo se muestran los datos, solo tocas la Vista. Si cambia una regla de negocio, solo tocas el Modelo. Un cambio en una capa no debería romper las otras.
*   **Facilita las pruebas (Testing):** Es mucho más fácil hacer pruebas unitarias de la lógica de negocio en los Modelos de forma aislada, sin tener que lidiar con la interfaz de usuario.

!!! warning "El error más común"
    El error de novato más frecuente es poner consultas a la base de datos (`SELECT`, `INSERT`, etc.) dentro de la Vista. ¡Nunca, jamás, hagas eso! La Vista solo pide y muestra datos. El Modelo es el único que habla con la base de datos.

### 4.3 - Ejemplos

Veamos la magia del MVC transformando un simple script PHP.

#### Ejemplo 1: El Caos Monolítico (El "Antes")

Imagina un archivo `articulos.php` que muestra una lista de artículos de una base de datos.

```php
<?php
// articulos.php - TODO EN UN MISMO SITIO

// 1. Lógica de conexión y datos (¡Esto es trabajo del MODELO!)
$dsn = 'mysql:host=localhost;dbname=mi_blog';
$usuario = 'root';
$contrasena = 'password';

try {
    $pdo = new PDO($dsn, $usuario, $contrasena);
    $consulta = $pdo->query('SELECT fecha, titulo FROM articulo');
    $articulos = $consulta->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error de conexión: ' . $e->getMessage());
}

// 2. Lógica de presentación (¡Esto es trabajo de la VISTA!)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Artículos</title>
</head>
<body>
    <h1>Listado de Artículos</h1>
    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Título</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($articulos as $articulo): ?>
                <tr>
                    <td><?= htmlspecialchars($articulo['fecha']) ?></td>
                    <td><?= htmlspecialchars($articulo['titulo']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
```

Este código funciona, pero es un desastre esperando a ocurrir. Mezcla conexión, consulta y HTML.

#### Ejemplo 2: El Orden MVC (El "Después")

Ahora, reorganicemos el mismo código siguiendo el patrón MVC. Necesitaremos varios archivos:

**`index.php` (Punto de Entrada / Controlador Frontal)**
Este archivo recibe todas las peticiones y decide qué controlador ejecutar.

```php
<?php
// index.php

require_once 'controllers/ArticleController.php';

$controller = new ArticleController();
$controller->listArticles();
```

**`models/ArticleModel.php` (El Modelo)**
Encapsula toda la lógica de la base de datos.

```php
<?php
// models/ArticleModel.php

class ArticleModel
{
    private PDO $pdo;

    public function __construct()
    {
        // La configuración de la BD debería estar en un archivo aparte, pero para simplificar:
        $dsn = 'mysql:host=localhost;dbname=mi_blog';
        $usuario = 'root';
        $contrasena = 'password';

        try {
            $this->pdo = new PDO($dsn, $usuario, $contrasena);
        } catch (PDOException $e) {
            die('Error de conexión: ' . $e->getMessage());
        }
    }

    /**
     * Obtiene todos los artículos de la base de datos.
     * @return array
     */
    public function getAllArticles(): array
    {
        $consulta = $this->pdo->query('SELECT fecha, titulo FROM articulo');
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }
}
```

**`controllers/ArticleController.php` (El Controlador)**
El intermediario. Pide los datos al Modelo y carga la Vista.

```php
<?php
// controllers/ArticleController.php

require_once 'models/ArticleModel.php';

class ArticleController
{
    public function listArticles()
    {
        $articleModel = new ArticleModel();
        $articles = $articleModel->getAllArticles();

        // Pasa los datos a la vista y la carga
        require 'views/article_list_view.php';
    }
}
```

**`views/article_list_view.php` (La Vista)**
El archivo de presentación. Solo contiene HTML y la lógica mínima para mostrar los datos.

```php
<!-- views/article_list_view.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Artículos</title>
</head>
<body>
    <h1>Listado de Artículos</h1>
    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Título</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($articles as $article): ?>
                <tr>
                    <td><?= htmlspecialchars($article['fecha']) ?></td>
                    <td><?= htmlspecialchars($article['titulo']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
```
¡Observa la claridad! Cada archivo tiene una responsabilidad única. Si mañana queremos cambiar la tabla HTML por una lista `<ul>`, solo modificamos la vista. Si queremos cambiar de MySQL a PostgreSQL, solo modificamos el modelo. El controlador ni se entera. ¡Esto, amigo mío, es programar de forma profesional!

!!! question "Reflexiona"
    1. En el ejemplo MVC, ¿dónde añadirías el código para manejar el envío de un formulario para crear un nuevo artículo? ¿En qué archivo y en qué método?
    2. Si quisieras mostrar los artículos en un formato diferente, como JSON para una API, ¿qué partes del código MVC tendrías que reutilizar y qué parte tendrías que crear de nuevo?
    3. ¿Qué es un "Controlador Frontal" (Front Controller) y por qué el archivo `index.php` en el ejemplo MVC cumple esa función?

<br/><hr/>

## Aplicación en el Mundo Real

Prácticamente **todos los frameworks modernos de PHP se basan en el patrón MVC** o en una variación del mismo.

*   **Laravel:** Es uno de los frameworks PHP más populares y sigue una implementación muy clara de MVC. Tiene directorios para `Models`, `Views` y `Controllers`, y su sistema de enrutamiento (`routes/web.php`) actúa como un potente controlador frontal.
*   **Symfony:** Otro gigante del ecosistema PHP. Aunque es más modular y a veces se describe como un framework "Request-Response", la estructura fundamental que promueve para las aplicaciones web es MVC.
*   **Laminas (antes Zend Framework):** También se basa fuertemente en MVC, proporcionando componentes para cada parte del patrón.

Entender MVC no es solo un ejercicio académico; es el requisito indispensable para poder trabajar con estas herramientas profesionales. Te da el mapa mental para entender cómo están organizados estos frameworks y cómo construir aplicaciones complejas sobre ellos. Cuando una empresa te pida "experiencia en Laravel", lo que realmente está evaluando es si entiendes la filosofía MVC que hay detrás.

## Para Saber Más

Si te ha picado la curiosidad y quieres profundizar, aquí tienes algunos recursos de altísima calidad:

1.  **Documentación de Laravel - The Basics:** La documentación oficial de Laravel tiene una de las mejores introducciones prácticas a los conceptos de MVC, aunque centrada en su framework. [Échale un vistazo aquí](https://laravel.com/docs/11.x/lifecycle).
2.  **Artículo de SitePoint - "MVC for Noobs":** Un artículo clásico, pero todavía muy relevante, que explica los fundamentos de MVC en PHP desde cero, de una forma muy amigable. [Leer el artículo (en inglés)](https://www.sitepoint.com/mvc-for-noobs/).
3.  **Video-Tutorial - "MVC from Scratch" por Traversy Media:** Si eres más de aprender en vídeo, este tutorial te guía paso a paso en la creación de un pequeño framework MVC en PHP desde un archivo en blanco. Imprescindible para asentar los conceptos. [Ver el vídeo en YouTube (en inglés)](https://www.youtube.com/watch?v=6ERdu4k62wI).