
# Ejercicios Prácticos: Control de Flujo en PHP

¡Equipo de DevCore! Hemos sentado las bases de la lógica de PHP. Ahora es el momento de poner a prueba vuestras nuevas habilidades. Os enfrentaréis al desarrollo de varios módulos para nuestra nueva **"DevCore Internal Tools Suite"**, una aplicación interna para gestionar recursos y operaciones de la empresa.

Cada ejercicio representa un ticket de desarrollo para una funcionalidad específica. ¡Manos al código!

## Ejercicios de Consolidación

Estos ejercicios iniciales están diseñados para afianzar los conceptos fundamentales del control de flujo. Son los pilares sobre los que construiremos funcionalidades más complejas.

!!! abstract "Módulo de Acceso: Validador de Roles | Nivel: Fácil"
    #### Objetivo
    Crear un script que simule un control de acceso básico. Dependiendo del rol de un usuario, el sistema deberá mostrar un mensaje de bienvenida diferente y determinar si tiene o no permisos de administrador.

    #### Tarea a realizar
    1.  Crea una variable `$userRole` y asígnale uno de estos valores: `'admin'`, `'editor'`, `'viewer'`.
    2.  Crea una variable booleana `$isAdmin` inicializada a `false`.
    3.  Escribe una estructura `if/elseif/else` que haga lo siguiente:
        *   Si `$userRole` es `'admin'`, debe imprimir "Bienvenido, Administrador. Tienes acceso total." y cambiar `$isAdmin` a `true`.
        *   Si `$userRole` es `'editor'`, debe imprimir "Bienvenido, Editor. Puedes gestionar el contenido."
        *   Para cualquier otro rol, debe imprimir "Bienvenido, Visitante. Solo tienes permisos de lectura."
    4.  Al final del script, imprime el valor de la variable `$isAdmin` para verificar que ha cambiado correctamente solo en el caso del administrador.

    #### Aplicación en el Mundo Real
    Este es el sistema de permisos más básico que existe. En cualquier aplicación (un CMS, un ERP, una red social), el servidor comprueba constantemente el rol del usuario para decidir si puede ver una página, editar un campo o eliminar un registro.

    ??? success "VER Solución."
        ```php
        <?php
        
        // 1. Definir variables iniciales
        $userRole = 'admin'; // Prueba cambiando este valor a 'editor' o 'viewer'
        $isAdmin = false;
        
        echo "<h1>Control de Acceso</h1>";
        
        // 3. Estructura if/elseif/else
        if ($userRole === 'admin') {
            echo "<p>Bienvenido, Administrador. Tienes acceso total.</p>";
            $isAdmin = true;
        } elseif ($userRole === 'editor') {
            echo "<p>Bienvenido, Editor. Puedes gestionar el contenido.</p>";
        } else {
            echo "<p>Bienvenido, Visitante. Solo tienes permisos de lectura.</p>";
        }
        
        // 4. Verificación final del flag
        echo "<h4>Verificación de permisos:</h4>";
        echo "<p>¿Es administrador? " . ($isAdmin ? 'Sí' : 'No') . "</p>";
        
        ?>
        ```

!!! abstract "Módulo de Monitorización: Notificador de Estado del Servidor | Nivel: Fácil"
    #### Objetivo
    Implementar un script que muestre un mensaje legible para un humano a partir de un código de estado numérico que podría provenir de un sistema de monitorización.

    #### Tarea a realizar
    1.  Define una variable `$statusCode` con un valor numérico, por ejemplo, `200`.
    2.  Usando una sentencia `switch`, evalúa la variable `$statusCode`:
        *   `case 200`: imprime "Estado: OK - Petición correcta."
        *   `case 301`: imprime "Estado: Moved Permanently - Redirección permanente."
        *   `case 404`: imprime "Estado: Not Found - El recurso no se encontró."
        *   `case 500`: imprime "Estado: Internal Server Error - Error en el servidor."
        *   `default`: imprime "Código de estado no reconocido."
    3.  Asegúrate de que cada `case` tiene su correspondiente `break;`. Prueba el script cambiando el valor de `$statusCode` a `404`, `503` (que usará el `default`), etc.

    #### Aplicación en el Mundo Real
    Las APIs y los servicios web se comunican constantemente con códigos de estado (HTTP, errores internos, etc.). Transformar estos códigos en mensajes claros es fundamental para la depuración (logs) y para mostrar mensajes de error útiles a los usuarios finales.

    ??? success "VER Solución."
        ```php
        <?php
        
        // 1. Definir variable
        $statusCode = 404; // Cambia este valor para probar los diferentes casos
        
        echo "<h2>Notificador de Estado del Servidor</h2>";
        
        // 2. Sentencia switch
        switch ($statusCode) {
            case 200:
                echo "<p style='color: green;'>Estado: OK - Petición correcta.</p>";
                break;
            case 301:
                echo "<p style='color: orange;'>Estado: Moved Permanently - Redirección permanente.</p>";
                break;
            case 404:
                echo "<p style='color: red;'>Estado: Not Found - El recurso no se encontró.</p>";
                break;
            case 500:
                echo "<p style='color: darkred;'>Estado: Internal Server Error - Error en el servidor.</p>";
                break;
            default:
                echo "<p>Código de estado no reconocido: $statusCode</p>";
                break;
        }
        
        ?>
        ```

!!! abstract "Bug Hunt: El Procesador de Tareas Infinito | Nivel: Fácil"
    #### Objetivo
    Depurar un pequeño script que contiene un error muy común: un bucle infinito. Deberás encontrar la causa del problema y solucionarlo.

    #### Setup Inicial
    Aquí tienes el código defectuoso:

    ```php
    <?php
    $tareasEnCola = 5;
    
    echo "<h3>Iniciando procesador de tareas...</h3>";
    
    while ($tareasEnCola > 0) {
        echo "<p>Procesando una tarea... quedan $tareasEnCola.</p>";
        // Falta algo aquí...
    }
    
    echo "<h3>¡Todas las tareas han sido procesadas!</h3>";
    ?>
    ```

    #### Tarea a realizar
    1.  Copia el código anterior en un fichero PHP.
    2.  Analiza el bucle `while`. ¿Por qué la condición `$tareasEnCola > 0` nunca deja de ser cierta?
    3.  Añade la línea de código que falta dentro del bucle para que el script se ejecute correctamente y termine, mostrando el mensaje final.

    #### Aplicación en el Mundo Real
    Los bucles infinitos son un bug grave. Pueden hacer que un script consuma el 100% de la CPU de un servidor, agote la memoria y bloquee por completo una aplicación. Aprender a detectarlos y, sobre todo, a prevenirlos (asegurándose de que la condición de salida del bucle se alcanzará eventualmente) es una habilidad de depuración crítica.

    ??? success "VER Solución."
        El problema es que la variable `$tareasEnCola` nunca se modifica dentro del bucle. Por lo tanto, si empieza siendo `5`, siempre será `5`, y la condición `5 > 0` siempre será verdadera. La solución es decrementar la variable en cada iteración.

        ```php
        <?php
        $tareasEnCola = 5;
        
        echo "<h3>Iniciando procesador de tareas...</h3>";
        
        while ($tareasEnCola > 0) {
            echo "<p>Procesando una tarea... quedan $tareasEnCola.</p>";
            // SOLUCIÓN: Decrementar el contador de tareas.
            $tareasEnCola--; 
        }
        
        echo "<h3>¡Todas las tareas han sido procesadas!</h3>";
        ?>
        ```

!!! abstract "Módulo de Inventario: Generador de Etiquetas | Nivel: Fácil"
    #### Objetivo
    Usar un bucle `for` para generar una serie de etiquetas de inventario con un formato específico.

    #### Tarea a realizar
    1.  Vas a generar etiquetas para un lote de 15 nuevos servidores. El formato de la etiqueta es `SRV-2025-XX`, donde `XX` es un número secuencial de 01 a 15.
    2.  Utiliza un bucle `for` que itere desde 1 hasta 15.
    3.  Dentro del bucle, debes generar el número de serie con dos dígitos (es decir, `01`, `02`, ..., `09`, `10`). Puedes usar la función `str_pad()` de PHP para esto. Investiga cómo funciona.
    4.  Imprime cada etiqueta generada en un párrafo HTML. Ejemplo: `<p>Etiqueta generada: SRV-2025-01</p>`.

    #### Aplicación en el Mundo Real
    Generar identificadores únicos, nombres de fichero secuenciales, opciones para un `<select>` en un formulario, o simplemente repetir una acción un número conocido de veces, son tareas perfectas para un bucle `for`.

    ??? success "VER Solución."
        ```php
        <?php
        
        echo "<h2>Generador de Etiquetas de Inventario</h2>";
        $prefijo = "SRV-2025-";
        $cantidad = 15;
        
        // 2. Bucle for de 1 a 15
        for ($i = 1; $i <= $cantidad; $i++) {
            // 3. Formatear el número a dos dígitos
            $numeroSecuencial = str_pad($i, 2, '0', STR_PAD_LEFT);
            
            // 4. Imprimir la etiqueta
            echo "<p>Etiqueta generada: $prefijo" . $numeroSecuencial . "</p>";
        }
        
        ?>
        ```
        *Nota sobre `str_pad()`: `str_pad($i, 2, '0', STR_PAD_LEFT)` le dice a PHP: "Toma la variable `$i`. Si su longitud es menor de `2` caracteres, rellénala con el string `'0'` por la `izquierda` (STR_PAD_LEFT) hasta que tenga 2 caracteres de longitud".*

!!! abstract "Módulo de Directorio: Listado del Equipo de IT | Nivel: Fácil"
    #### Objetivo
    Mostrar una lista de los miembros del equipo de IT utilizando un bucle `foreach` para recorrer un array asociativo.

    #### Setup Inicial
    Usa el siguiente array que contiene los datos de los empleados:
    ```php
    <?php
    $equipoIT = [
        "S01" => "Ana García (SysAdmin)",
        "S02" => "Carlos Pérez (Networking)",
        "D01" => "Elena Ruiz (DevOps)",
        "D02" => "Marcos Vega (Developer)"
    ];
    ?>
    ```

    #### Tarea a realizar
    1.  Copia el array `$equipoIT` en tu script.
    2.  Escribe un bucle `foreach` que recorra el array. En cada iteración, necesitarás tanto la clave (el ID de empleado) como el valor (el nombre y puesto).
    3.  Dentro del bucle, imprime cada miembro del equipo en un formato claro, por ejemplo: `"ID: S01 | Miembro: Ana García (SysAdmin)"`. Envuelve cada entrada en un elemento de lista `<li>`.
    4.  Envuelve toda la salida en una lista no ordenada `<ul>`.

    #### Aplicación en el Mundo Real
    `foreach` es, con diferencia, el bucle más utilizado en PHP. Cada vez que una aplicación recupera una lista de elementos de una base de datos (usuarios, productos, posts, etc.), los recibe como un array y usa un `foreach` para mostrarlos en una tabla, una lista o una serie de tarjetas en la interfaz.

    ??? success "VER Solución."
        ```php
        <?php
        $equipoIT = [
            "S01" => "Ana García (SysAdmin)",
            "S02" => "Carlos Pérez (Networking)",
            "D01" => "Elena Ruiz (DevOps)",
            "D02" => "Marcos Vega (Developer)"
        ];
        
        echo "<h2>Directorio del Equipo de IT</h2>";
        
        // 4. Abrir la lista
        echo "<ul>";
        
        // 2. Bucle foreach con clave y valor
        foreach ($equipoIT as $id => $nombre) {
            // 3. Imprimir cada elemento
            echo "<li><strong>ID: $id</strong> | Miembro: $nombre</li>";
        }
        
        // 4. Cerrar la lista
        echo "</ul>";
        
        ?>
        ```

!!! abstract "Módulo de UI: Mensaje de Bienvenida Condicional | Nivel: Fácil"
    #### Objetivo
    Utilizar el operador ternario para mostrar un mensaje de bienvenida u otro, de forma concisa, basándose en si el usuario ha iniciado sesión.

    #### Tarea a realizar
    1.  Define una variable booleana `$isLoggedIn` y asígnale el valor `true` o `false` para probar.
    2.  Define una variable `$username` con un nombre de usuario, por ejemplo, `'d.vega'`.
    3.  Usando el operador ternario `?:`, asigna un valor a una nueva variable `$welcomeMessage`.
        *   Si `$isLoggedIn` es `true`, el mensaje debe ser `"Bienvenido de nuevo, $username"`.
        *   Si es `false`, el mensaje debe ser `"Por favor, inicia sesión para continuar."`
    4.  Imprime la variable `$welcomeMessage` dentro de una etiqueta `<h1>`.

    #### Aplicación en el Mundo Real
    El operador ternario es muy común para pequeñas asignaciones condicionales directamente en la vista o al preparar datos. Por ejemplo, para poner una clase CSS `class="activo"` si una opción de menú es la actual, o `class=""` si no lo es. Mantiene el código limpio y evita `if/else` largos para casos muy simples.

    ??? success "VER Solución."
        ```php
        <?php
        
        // 1 y 2. Variables iniciales
        $isLoggedIn = true; // Cambia a false para ver el otro mensaje
        $username = 'd.vega';
        
        // 3. Operador ternario
        $welcomeMessage = $isLoggedIn 
            ? "Bienvenido de nuevo, $username" 
            : "Por favor, inicia sesión para continuar.";
            
        // 4. Imprimir resultado
        echo "<h1>$welcomeMessage</h1>";
        
        ?>
        ```

## Ejercicios de Refuerzo

Estos ejercicios aumentan la complejidad, combinando varias estructuras de control para resolver un problema más elaborado. Se proporcionan algunas pistas y el setup inicial.

!!! warning "Módulo de Seguridad: Analizador de Logs | Nivel: Medio"
    #### Objetivo
    Crear un script que procese una lista de eventos de log y cuente cuántos son de tipo `ERROR`, `WARNING` y `INFO`, ignorando las entradas de `DEBUG`.

    #### Setup Inicial
    Aquí tienes un array que simula las líneas de un fichero de log:
    ```php
    <?php
    $logEntries = [
        "[INFO]: User 'admin' logged in.",
        "[INFO]: System startup complete.",
        "[WARNING]: Disk space is running low (15%).",
        "[ERROR]: Failed to connect to database 'prod_db'.",
        "[DEBUG]: Caching results for query X.",
        "[INFO]: New post published by 'e.ruiz'.",
        "[ERROR]: Payment gateway timeout for transaction #12345.",
        "[DEBUG]: User session data updated.",
        "[WARNING]: API endpoint 'v1/users' is deprecated."
    ];
    ?>
    ```

    #### Tarea a realizar
    1.  Define tres variables contadoras: `$errorCount`, `$warningCount`, `$infoCount`, todas inicializadas a `0`.
    2.  Usa un bucle `foreach` para iterar sobre el array `$logEntries`.
    3.  Dentro del bucle, para cada `$entry`, usa sentencias `if/elseif` para determinar el tipo de log.
        *   **Pista:** La función `str_starts_with()` es ideal aquí. Por ejemplo: `str_starts_with($entry, '[ERROR]')`.
    4.  Incrementa el contador correspondiente según el tipo de entrada. No hagas nada para las entradas `[DEBUG]`.
    5.  Al final del script, imprime un resumen con los totales, por ejemplo: "Análisis de Logs Completo: 2 Errores, 2 Advertencias, 3 Informaciones."

    #### Aplicación en el Mundo Real
    Los administradores de sistemas y desarrolladores a menudo crean scripts para analizar logs, buscar patrones de error, generar alertas o crear estadísticas de uso. Este ejercicio simula el núcleo lógico de una de esas herramientas de monitorización.

    ??? success "VER Solución."
        ```php
        <?php
        
        $logEntries = [
            "[INFO]: User 'admin' logged in.",
            "[INFO]: System startup complete.",
            "[WARNING]: Disk space is running low (15%).",
            "[ERROR]: Failed to connect to database 'prod_db'.",
            "[DEBUG]: Caching results for query X.",
            "[INFO]: New post published by 'e.ruiz'.",
            "[ERROR]: Payment gateway timeout for transaction #12345.",
            "[DEBUG]: User session data updated.",
            "[WARNING]: API endpoint 'v1/users' is deprecated."
        ];
        
        // 1. Inicializar contadores
        $errorCount = 0;
        $warningCount = 0;
        $infoCount = 0;
        
        echo "<h2>Analizando logs...</h2>";
        
        // 2. Recorrer el array
        foreach ($logEntries as $entry) {
            // 3. Comprobar el tipo de entrada
            if (str_starts_with($entry, '[ERROR]')) {
                $errorCount++;
            } elseif (str_starts_with($entry, '[WARNING]')) {
                $warningCount++;
            } elseif (str_starts_with($entry, '[INFO]')) {
                $infoCount++;
            }
            // Las entradas [DEBUG] se ignoran implícitamente
        }
        
        // 5. Imprimir el resumen
        echo "<h3>Análisis de Logs Completo:</h3>";
        echo "<p style='color: red;'>$errorCount Errores</p>";
        echo "<p style='color: orange;'>$warningCount Advertencias</p>";
        echo "<p style='color: blue;'>$infoCount Informaciones</p>";
        
        ?>
        ```

!!! warning "Módulo de UI: Refactorización a `match` | Nivel: Medio"
    #### Objetivo
    Refactorizar una función que usa una sentencia `switch` tradicional a una expresión `match` de PHP 8, para hacerla más concisa y segura.

    #### Setup Inicial
    Aquí tienes una función que devuelve el nombre de una clase CSS basado en el tipo de una alerta:
    ```php
    <?php
    function getAlertClass($type) {
        $class = '';
        switch ($type) {
            case 'success':
            case 'ok':
                $class = 'alert-success';
                break;
            case 'error':
            case 'danger':
                $class = 'alert-danger';
                break;
            case 'warning':
                $class = 'alert-warning';
                break;
            case 'info':
                $class = 'alert-info';
                break;
            default:
                $class = 'alert-secondary';
        }
        return $class;
    }
    
    $alertType = 'danger';
    echo "La clase para el tipo '$alertType' es: " . getAlertClass($alertType);
    ?>
    ```

    #### Tarea a realizar
    1.  Crea una nueva función llamada `getAlertClassWithMatch($type)`.
    2.  Dentro de esta nueva función, replica la lógica de la función original, pero usando una expresión `match`.
    3.  La expresión `match` debe devolver directamente el valor de la clase CSS, que será el valor de retorno de la función.
        *   **Pista:** Recuerda que en `match` puedes agrupar valores con comas y no necesitas `break`.
    4.  Compara ambas funciones. ¿Cuáles son las ventajas de la versión con `match`? (Piensa en legibilidad y seguridad ante errores de tipado).

    #### Aplicación en el Mundo Real
    Refactorizar código antiguo es una tarea muy común. Usar características modernas del lenguaje (como `match`) no solo hace el código más corto y elegante, sino que también lo hace más robusto y fácil de mantener, reduciendo la probabilidad de bugs sutiles como el "fall-through" de `switch`.

    ??? success "VER Solución."
        ```php
        <?php
        
        // Función original con switch para comparación
        function getAlertClass($type) {
            $class = '';
            switch ($type) {
                case 'success':
                case 'ok':
                    $class = 'alert-success';
                    break;
                case 'error':
                case 'danger':
                    $class = 'alert-danger';
                    break;
                case 'warning':
                    $class = 'alert-warning';
                    break;
                case 'info':
                    $class = 'alert-info';
                    break;
                default:
                    $class = 'alert-secondary';
            }
            return $class;
        }
        
        // 1 y 2. Nueva función con match
        function getAlertClassWithMatch($type) {
            // 3. La expresión match devuelve directamente el valor
            return match ($type) {
                'success', 'ok' => 'alert-success',
                'error', 'danger' => 'alert-danger',
                'warning' => 'alert-warning',
                'info' => 'alert-info',
                default => 'alert-secondary',
            };
        }
        
        $alertType = 'warning';
        echo "<p>Con switch: la clase para '$alertType' es: <b>" . getAlertClass($alertType) . "</b></p>";
        echo "<p>Con match: la clase para '$alertType' es: <b>" . getAlertClassWithMatch($alertType) . "</b></p>";
        
        // 4. Ventajas de match:
        // - Más conciso: No hay `break`, ni asignaciones repetidas a `$class`.
        // - Devuelve un valor: Se integra de forma natural con `return`.
        // - Comparación estricta (===): Evita bugs si $type fuera, por ejemplo, el número 0.
        // - Exhaustividad: Lanzaría un error si no hubiera un `default` y se pasara un valor no contemplado.
        
        ?>
        ```

!!! warning "Módulo de CMS: Generador de Menú Dinámico | Nivel: Medio"
    #### Objetivo
    Construir un menú de navegación HTML dinámicamente a partir de un array de configuración, mostrando solo los elementos a los que el usuario actual tiene acceso.

    #### Setup Inicial
    ```php
    <?php
    $currentUserRole = 'editor'; // Cambiar a 'admin' o 'guest' para probar

    $menuItems = [
        'Inicio' => ['url' => '/', 'access' => ['guest', 'editor', 'admin']],
        'Gestor de Contenidos' => ['url' => '/admin/content', 'access' => ['editor', 'admin']],
        'Gestor de Usuarios' => ['url' => '/admin/users', 'access' => ['admin']],
        'Perfil' => ['url' => '/profile', 'access' => ['editor', 'admin']],
        'Login' => ['url' => '/login', 'access' => ['guest']]
    ];
    ?>
    ```

    #### Tarea a realizar
    1.  Crea una cadena de texto que contenga la apertura de una etiqueta `<nav><ul>`.
    2.  Usa un bucle `foreach` para iterar sobre `$menuItems`. Necesitarás la clave (el nombre del item) y el valor (el array con `url` y `access`).
    3.  Dentro del bucle `foreach`, añade una condición `if`.
        *   **Pista:** La condición debe comprobar si `$currentUserRole` existe dentro del array `access` del item actual. La función `in_array()` es perfecta para esto.
    4.  Si la condición es verdadera, concatena el elemento de menú (`<li><a href="...">...</a></li>`) a tu cadena de texto.
    5.  Después del bucle, cierra las etiquetas `</ul></nav>`.
    6.  Imprime la cadena de texto completa del menú.
    7.  Prueba cambiando `$currentUserRole` para ver cómo el menú se adapta.

    #### Aplicación en el Mundo Real
    Esta es exactamente la lógica que usan los CMS (WordPress, Drupal) y frameworks (Laravel, Symfony) para construir menús, barras laterales y otros elementos de la interfaz. La UI se define en un fichero de configuración o en la base de datos, y el código la renderiza dinámicamente según los permisos del usuario que ha iniciado sesión.

    ??? success "VER Solución."
        ```php
        <?php
        
        $currentUserRole = 'admin'; // Cambiar a 'editor' o 'guest' para probar
        
        $menuItems = [
            'Inicio' => ['url' => '/', 'access' => ['guest', 'editor', 'admin']],
            'Gestor de Contenidos' => ['url' => '/admin/content', 'access' => ['editor', 'admin']],
            'Gestor de Usuarios' => ['url' => '/admin/users', 'access' => ['admin']],
            'Perfil' => ['url' => '/profile', 'access' => ['editor', 'admin']],
            'Login' => ['url' => '/login', 'access' => ['guest']]
        ];
        
        echo "<h2>Menú de Navegación para el rol: $currentUserRole</h2>";
        
        // 1. Iniciar el HTML del menú
        $menuHtml = "<nav><ul>\n";
        
        // 2. Recorrer los items
        foreach ($menuItems as $itemName => $itemData) {
            // 3. Comprobar permisos
            if (in_array($currentUserRole, $itemData['access'])) {
                // 4. Construir el elemento <li> si hay acceso
                $menuHtml .= "\t<li><a href=\"{$itemData['url']}\">$itemName</a></li>\n";
            }
        }
        
        // 5. Cerrar las etiquetas
        $menuHtml .= "</ul></nav>";
        
        // 6. Imprimir el menú completo
        echo $menuHtml;
        
        ?>
        ```

## Ejercicios de Ampliación

Estos son retos abiertos que requieren aplicar el conocimiento de forma creativa, investigar y colaborar. La solución es una propuesta, pero pueden existir otras igualmente válidas.

!!! danger "Módulo de BI: Generador de Informes de Ventas | Nivel: Alto"
    #### Objetivo
    Crear un script complejo que procese un array de datos de ventas para generar un informe HTML. El script debe aplicar varias reglas de negocio usando `if`, `continue` y `break`.

    #### Setup Inicial
    ```php
    <?php
    $salesData = [
        ['id' => 'S001', 'product' => 'Teclado Mecánico', 'category' => 'Hardware', 'amount' => 120.00],
        ['id' => 'S002', 'product' => 'Licencia Antivirus', 'category' => 'Software', 'amount' => 80.00],
        ['id' => 'S003', 'product' => 'Monitor Ultrawide', 'category' => 'Hardware', 'amount' => 350.50],
        ['id' => 'S004', 'product' => 'Suscripción Cloud', 'category' => 'Services', 'amount' => 50.00],
        ['id' => 'S005', 'product' => 'FLAG_FRAUD_CHECK', 'category' => 'Security', 'amount' => 0.00],
        ['id' => 'S006', 'product' => 'Ratón Gaming', 'category' => 'Hardware', 'amount' => 75.00],
    ];
    ?>
    ```

    #### Tarea a realizar
    1.  Tu objetivo es generar una tabla HTML con el informe. Inicializa las variables necesarias: un contador para el total de ventas (`$totalSales`) y una cadena para el HTML de la tabla.
    2.  Recorre el array `$salesData` con un `foreach`.
    3.  Dentro del bucle, aplica las siguientes reglas en orden:
        a.  **Control de Seguridad:** Si el `id` del producto es `'FLAG_FRAUD_CHECK'`, el sistema debe detenerse inmediatamente. Imprime un mensaje de alerta **fuera** de la tabla y detén el bucle por completo. Usa `break`.
        b.  **Exclusión de Categoría:** El informe no debe incluir ventas de la categoría `'Services'`. Si una venta es de esta categoría, sáltala y pasa a la siguiente iteración. Usa `continue`.
        c.  **Resaltado de Ventas Altas:** Si el `amount` de una venta es superior a 200.00, la fila (`<tr>`) de la tabla para esa venta debe tener un estilo CSS para destacarla (ej: `style="background-color: #d4edda;"`).
    4.  Para cada venta válida, añade su importe a `$totalSales` y construye la fila `<tr>` correspondiente para la tabla.
    5.  Al final, después del bucle, cierra la tabla y añade una fila de pie de tabla (`<tfoot>`) con el total de ventas calculado.
    6.  **Revisión por Pares (Peer Review):**
        *   Intercambia tu solución con un compañero.
        *   Evalúa su código: ¿La lógica es correcta? ¿Se aplican bien `break` y `continue`? ¿El HTML generado es válido? ¿El código es legible y está bien comentado?
        *   Proporciona 2-3 sugerencias de mejora constructivas.

    #### Aplicación en el Mundo Real
    Los sistemas de Business Intelligence (BI) y reporting constantemente procesan grandes volúmenes de datos. Los programadores deben implementar reglas de negocio complejas (filtrar, agregar, transformar datos y manejar casos excepcionales) para que los informes sean precisos y relevantes para la toma de decisiones.

    ??? success "VER Solución."
        ```php
        <?php
        
        $salesData = [
            ['id' => 'S001', 'product' => 'Teclado Mecánico', 'category' => 'Hardware', 'amount' => 120.00],
            ['id' => 'S002', 'product' => 'Licencia Antivirus', 'category' => 'Software', 'amount' => 80.00],
            ['id' => 'S003', 'product' => 'Monitor Ultrawide', 'category' => 'Hardware', 'amount' => 350.50],
            ['id' => 'S004', 'product' => 'Suscripción Cloud', 'category' => 'Services', 'amount' => 50.00],
            ['id' => 'S005', 'product' => 'FLAG_FRAUD_CHECK', 'category' => 'Security', 'amount' => 0.00],
            ['id' => 'S006', 'product' => 'Ratón Gaming', 'category' => 'Hardware', 'amount' => 75.00],
        ];

        // 1. Inicialización
        $totalSales = 0.0;
        $tableHtml = '<table border="1" cellpadding="5" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID Venta</th>
                                <th>Producto</th>
                                <th>Categoría</th>
                                <th>Importe</th>
                            </tr>
                        </thead>
                        <tbody>';
        $alertMessage = '';

        // 2. Recorrer datos
        foreach ($salesData as $sale) {
            // 3a. Control de Seguridad (break)
            if ($sale['product'] === 'FLAG_FRAUD_CHECK') {
                $alertMessage = '<p style="color:red; font-weight:bold;">ALERTA: Se detectó una transacción de seguridad. El procesamiento se ha detenido.</p>';
                break;
            }
            
            // 3b. Exclusión de categoría (continue)
            if ($sale['category'] === 'Services') {
                continue;
            }

            // 3c. Resaltado de ventas altas
            $rowStyle = ($sale['amount'] > 200.00) ? 'style="background-color: #d4edda;"' : '';

            // 4. Construir fila y sumar total
            $tableHtml .= "<tr $rowStyle>
                                <td>{$sale['id']}</td>
                                <td>{$sale['product']}</td>
                                <td>{$sale['category']}</td>
                                <td>" . number_format($sale['amount'], 2) . " €</td>
                           </tr>";
            $totalSales += $sale['amount'];
        }

        // 5. Cerrar la tabla y añadir pie
        $tableHtml .= '</tbody>
                       <tfoot>
                           <tr>
                               <td colspan="3" style="text-align:right; font-weight:bold;">Total de Ventas Procesadas</td>
                               <td style="font-weight:bold;">' . number_format($totalSales, 2) . ' €</td>
                           </tr>
                       </tfoot>
                       </table>';

        echo "<h1>Informe de Ventas</h1>";
        if ($alertMessage) {
            echo $alertMessage;
        }
        echo $tableHtml;

        ?>
        ```

!!! danger "Reto de Entrevista: FizzBuzz Pro | Nivel: Alto"
    #### Objetivo
    Resolver una versión avanzada del conocido problema de programación "FizzBuzz", demostrando una lógica condicional clara y fácilmente extensible.

    #### Tarea a realizar
    1.  El reto base es: escribe un script que imprima los números del 1 al 100. Pero para los múltiplos de 3, imprime "Fizz" en lugar del número. Para los múltiplos de 5, imprime "Buzz". Para los números que son múltiplos de 3 y 5, imprime "FizzBuzz".
    2.  **Primera Extensión:** Modifica tu lógica para añadir una nueva regla: para los múltiplos de 7, imprime "Bang". Las reglas ahora se combinan (ej: 21 es múltiplo de 3 y 7, debería imprimir "FizzBang"; 35 es múltiplo de 5 y 7, debería imprimir "BuzzBang"; etc.).
    3.  **Segunda Extensión:** Modifica tu lógica de nuevo. La regla para el 7 cambia: ahora "Bang" solo debe aparecer en los múltiplos de 7, *sobrescribiendo* cualquier otra regla. (ej: 21 ahora es solo "Bang").
    4.  Organiza tu código para que sea lo más legible posible. El orden de las condiciones `if/elseif` es crucial.
    5.  **Revisión por Pares (Peer Review):**
        *   Analiza el código de tu compañero. ¿Es correcto según las tres fases del problema?
        *   ¿Qué tan fácil sería añadir una nueva regla, por ejemplo, "Boom" para los múltiplos de 11? ¿Su código es extensible o habría que reescribirlo casi por completo?
        *   Sugiere una forma de refactorizar su código (si es posible) para que añadir nuevas reglas sea aún más sencillo.

    #### Aplicación en el Mundo Real
    FizzBuzz es un filtro común en entrevistas técnicas. No prueba si sabes programar algoritmos complejos, sino si tienes un dominio absoluto de la lógica condicional básica, si puedes pensar en los casos borde y si escribes un código limpio y mantenible que pueda evolucionar cuando los requisitos cambian.

    ??? success "VER Solución."
        Esta es una posible solución que prioriza la legibilidad y la extensibilidad.

        ```php
        <?php
        echo "<h1>FizzBuzz Pro (Solución a la Fase 3)</h1>";

        for ($i = 1; $i <= 100; $i++) {
            // Fase 3: La regla del 7 sobrescribe a las demás, así que se comprueba primero.
            if ($i % 7 === 0) {
                echo "Bang<br>";
                continue; // Pasamos a la siguiente iteración
            }
            
            // Lógica para Fizz y Buzz
            $output = '';
            if ($i % 3 === 0) {
                $output .= 'Fizz';
            }
            if ($i % 5 === 0) {
                $output .= 'Buzz';
            }
            
            // Si $output no está vacío, lo imprimimos. Si no, imprimimos el número.
            if ($output) {
                echo $output . "<br>";
            } else {
                echo $i . "<br>";
            }
        }
        ?>
        ```
        **Análisis para Peer Review:**
        *   **Fase 1 (FizzBuzz clásico):** Se cumple con la lógica de los `if` anidados que construyen el string `$output`.
        *   **Fase 2 (Añadir "Bang" combinado):** Se lograría añadiendo un `if ($i % 7 === 0) { $output .= 'Bang'; }` junto a los otros. El enfoque de construir un string de salida (`$output`) es muy extensible.
        *   **Fase 3 (Añadir "Bang" que sobreescribe):** La solución propuesta lo implementa correctamente poniendo la condición del 7 al principio y usando `continue`. Esto hace la lógica un poco más compleja de seguir que una cadena de `if/elseif/else`, pero cumple el requisito a la perfección. Una alternativa sería una cascada de `if/elseif/else` donde el primer `if` es `if ($i % 3 === 0 && $i % 5 === 0 && $i % 7 === 0)` y así sucesivamente, pero eso sería mucho menos mantenible.

!!! danger "Investigación y Exposición: Motores de Plantillas | Nivel: Alto"
    #### Objetivo
    Investigar cómo los motores de plantillas modernos de PHP abstraen las estructuras de control para separar la lógica de la presentación, y realizar una pequeña demostración práctica.

    #### Tarea a realizar
    1.  **Investigación:** Elige uno de los siguientes motores de plantillas: **Twig** (usado por Symfony y Drupal) o **Blade** (usado por Laravel).
    2.  Investiga y documenta la sintaxis específica que utiliza para:
        *   Renderizar una variable (ej: `{{ miVariable }}`).
        *   Estructuras condicionales (`if/elseif/else`).
        *   Bucles para recorrer arrays (`for`).
        *   Comprobar si una variable está definida o no es nula.
    3.  **Implementación:**
        *   Crea un fichero PHP (`demo.php`) que defina un array de usuarios. Cada usuario debe ser un array asociativo con `nombre`, `rol` (`admin` o `user`) y `activo` (`true` o `false`).
        *   Pasa este array de usuarios al motor de plantillas que elegiste. (Para este ejercicio, no es necesario instalar el motor, puedes simular el código o simplemente mostrar los dos ficheros: el de PHP y el de la plantilla).
        *   Crea el fichero de plantilla (`demo.twig` o `demo.blade.php`) que reciba los datos.
        *   En la plantilla, implementa la siguiente lógica usando la sintaxis del motor:
            a.  Recorre la lista de usuarios.
            b.  Muestra el nombre de cada usuario.
            c.  Al lado del nombre, si el usuario es `admin`, muestra un icono o texto `(Admin)`.
            d.  Solo muestra usuarios que estén `activos`. Los inactivos no deben aparecer en la lista.
    4.  **Presentación y Peer Review:**
        *   Prepara una exposición de 5 minutos para la clase.
        *   Muestra el código de `demo.php` y el de tu plantilla.
        *   Explica cómo la sintaxis del motor de plantillas se corresponde con las estructuras de control de PHP que hemos estudiado.
        *   Muestra el resultado HTML final que generaría tu plantilla.
        *   Tus compañeros evaluarán la claridad de tu explicación y la correcta implementación de la lógica en la plantilla.

    #### Aplicación en el Mundo Real
    En proyectos profesionales de PHP, casi nunca se mezcla código PHP directamente con HTML como hemos hecho en los ejercicios. Se usan motores de plantillas para que los diseñadores front-end puedan trabajar en las vistas sin tocar la lógica de negocio, y los programadores back-end puedan enfocarse en los datos sin preocuparse por el HTML. Entender cómo funcionan es fundamental para trabajar con cualquier framework moderno.

    ??? success "VER Solución."
        Esta es una solución de ejemplo usando la sintaxis de **Twig**.

        **1. Fichero `demo.php` (Lógica de PHP)**
        ```php
        <?php
        // En un proyecto real, aquí estaría el código para cargar el motor Twig.
        // require_once '/path/to/vendor/autoload.php';
        // $loader = new \Twig\Loader\FilesystemLoader('./templates');
        // $twig = new \Twig\Environment($loader);

        // Definimos los datos que pasaremos a la plantilla
        $users = [
            ['name' => 'Ana García', 'role' => 'admin', 'active' => true],
            ['name' => 'Carlos Pérez', 'role' => 'user', 'active' => true],
            ['name' => 'David Jones', 'role' => 'user', 'active' => false], // Este no debería mostrarse
            ['name' => 'Elena Ruiz', 'role' => 'admin', 'active' => true],
        ];

        // En un proyecto real, llamaríamos al renderizado de Twig:
        // echo $twig->render('demo.twig', ['user_list' => $users]);
        
        // Para este ejercicio, solo definimos los datos y la plantilla.
        echo "Datos preparados para ser enviados a la plantilla Twig.";
        ?>
        ```

        **2. Fichero de Plantilla `templates/demo.twig` (Lógica de Presentación)**
        ```twig
        {# templates/demo.twig #}
        <h1>Lista de Usuarios del Sistema</h1>
        
        <ul>
        {# 1. Bucle 'for' para recorrer el array 'user_list' #}
        {% for user in user_list %}
        
            {# 2. Condición 'if' para mostrar solo usuarios activos #}
            {% if user.active %}
        
                <li>
                    {{ user.name }} {# Renderiza la variable 'name' #}
        
                    {# 3. Condición anidada para la insignia de Admin #}
                    {% if user.role == 'admin' %}
                        <strong>(Admin)</strong>
                    {% endif %}
                </li>
        
            {% endif %}
        
        {% endfor %}
        </ul>
        ```

        **3. Resultado HTML Esperado**
        ```html
        <h1>Lista de Usuarios del Sistema</h1>
        
        <ul>
            <li>
                Ana García 
                <strong>(Admin)</strong>
            </li>
            <li>
                Carlos Pérez 
            </li>
            <li>
                Elena Ruiz 
                <strong>(Admin)</strong>
            </li>
        </ul>
        ```