<!-- Nombre de archivo sugerido: T01-arquitecturas-web.md -->

# Arquitecturas Web: Los Cimientos de tu Futura App

¡Muy buenas! Bienvenidos al apasionante mundo del desarrollo en el lado del servidor. Hoy vamos a sentar las bases, literalmente. Si fueras a montar un restaurante de éxito, no empezarías a cocinar sin más, ¿verdad? Primero necesitarías un plano: dónde va la cocina, dónde las mesas, cómo se moverán los camareros... En el desarrollo web, esos planos son las **arquitecturas web**.

Hasta ahora, has trabajado principalmente en la "sala del restaurante": el `front-end`, lo que el cliente ve. Has usado HTML para la estructura, CSS para la decoración y JavaScript para que los camareros (el navegador) hagan trucos y validaciones rápidas. Pero el verdadero corazón, la **cocina**, es el `back-end`. Ahí es donde se preparan los datos, se accede a la despensa (base de datos) y se crea la magia.

Hoy vamos a aprender a diseñar esa cocina. Veremos cómo se comunican los clientes con el servidor y qué patrones de diseño nos evitarán que nuestra aplicación acabe siendo un caos de espaguetis... y no precisamente de los que se comen.

---

## Conceptos Fundamentales

Antes de ponernos el delantal de chef, aclaremos algunos términos. Son el "mise en place" de todo desarrollador.

!!! note "Definición: Cliente"
    Es quien inicia la conversación. En el 99% de los casos, será un **navegador web** (Chrome, Firefox, Safari...) que una persona utiliza en su ordenador, móvil o incluso en su nevera inteligente. Es el que tiene una necesidad y hace una **petición** (`request`).

!!! note "Definición: Servidor"
    Es el que escucha y contesta. Es un programa (y por extensión, el ordenador donde se ejecuta) que está 24/7 esperando peticiones. Cuando recibe una, la procesa y devuelve una **respuesta** (`response`). Piensa en él como la cocina del restaurante, siempre lista para recibir una comanda.

!!! note "Definición: Página Estática"
    Imagina que en la puerta del restaurante solo tienes un menú impreso en un corcho. No cambia, es siempre el mismo para todos y fue creado hace tiempo. Eso es una página estática. Está hecha de HTML, CSS y quizás algo de JS, pero su contenido está "quemado" en el archivo. Es rápida y sencilla, pero poco más.

!!! note "Definición: Página Dinámica"
    Aquí es donde la cosa se pone interesante. Entras al restaurante, un camarero te toma nota, y el chef te prepara un plato al momento, quizás con los ingredientes que has elegido. Una página dinámica se genera **en el momento de la petición**. El servidor ejecuta código (en nuestro caso, PHP) para consultar una base de datos, personalizar el contenido para ti y construir un HTML único para esa respuesta. La web 2.0 nació aquí.

---

## Desarrollo y Patrones de Arquitectura

Vale, ya sabemos quién pide y quién responde. Pero, ¿cómo organizamos el caos para que no acabemos con código por todas partes?

### El Duelo: Código en el Cliente vs. Código en el Servidor

No todo el código de una aplicación web vive en el mismo sitio. Se libra una batalla constante entre lo que debe ejecutarse en el navegador del usuario (`front-end`) y lo que debe ejecutarse en nuestro servidor (`back-end`).

- **Lado del Cliente (Front-End):** Se usa principalmente JavaScript. Es ideal para tareas que necesitan una respuesta inmediata y no comprometen la seguridad.
    - **Ejemplo:** Validar que un campo de email tiene el formato correcto (`nombre@dominio.com`) antes de enviarlo.
- **Lado del Servidor (Back-End):** Aquí es donde PHP, Python, Java y otros reinan. Se encarga de la lógica de negocio, el acceso a datos y la seguridad.
    - **Ejemplo:** Comprobar en la base de datos si el email que el usuario quiere registrar ya existe.

!!! tip "La Regla de Oro"
    **Nunca confíes en el cliente.** Cualquier validación de seguridad crítica (comprobar permisos, procesar un pago, verificar si un usuario puede ver un contenido) **DEBE** hacerse en el servidor. El código del cliente puede ser manipulado por un usuario con conocimientos.

!!! question
    1.  Para comprobar que la contraseña y su confirmación son idénticas en un formulario de registro, ¿usarías programación en el cliente o en el servidor? ¿Por qué?
    2.  Una tienda online quiere mostrar un aviso de "¡Quedan pocas unidades!" cuando el stock de un producto baja de 5. ¿Dónde se debería ejecutar esa lógica?
    3.  ¿Por qué crees que un juego online como Fortnite ejecuta la lógica de disparo y daño en el servidor y no en el cliente de cada jugador?

### La Arquitectura de 3 Capas: Organizando la Cocina

La mayoría de las aplicaciones profesionales no son un único bloque de código. Para mantener la cordura y facilitar el trabajo en equipo, se dividen en capas lógicas. La más común es la arquitectura de 3 capas.

1.  **Capa de Presentación (Vista):** Es con lo que el usuario interactúa. Su única misión es mostrar los datos de forma bonita y recoger las acciones del usuario. Es el comedor y el menú del restaurante.
2.  **Capa de Negocio (Lógica/Controlador):** Es el cerebro de la aplicación. Recibe las peticiones, aplica las reglas de negocio (ej: "un usuario no puede comprar sin saldo"), procesa los datos y decide qué hacer. Es el equipo de cocina que sigue las recetas.
3.  **Capa de Datos (Persistencia/Modelo):** Es el guardián de la información. Se encarga de hablar con la base de datos para guardar, leer, actualizar y borrar información. Es la despensa y el sistema de inventario.

```mermaid
    graph TD
    subgraph "Capa Física 1: Cliente"
        A[👨‍💻 Usuario <--> Navegador Web]
    end

    subgraph "Capa Física 2: Servidor de Aplicaciones"
        direction LR
        B{Controlador / Lógica} -- Pide datos --> C[Modelo / Capa de Datos]
        C -- Devuelve datos --> B
        B -- Envía datos a --> E[Vista / Capa de Presentación]
    end

    subgraph "Capa Física 3: Servidor de BBDD"
        D[(🗃️ MariaDB/MySQL)]
    end

    %% --- Flujo de la Petición ---
    A -- 1. Petición HTTP --> B
    C -- 2. Consulta SQL --> D
    D -- 3. Resultados --> C
    E -- 4. Respuesta HTML/CSS/JS --> A
```

!!! warning "Tier vs. Layer"
    No confundas las capas **lógicas** (*layer*) con las **físicas** (*tier*). Las capas lógicas organizan el código. Las capas físicas son las máquinas. En un proyecto gigante, cada capa lógica puede vivir en su propio servidor (o clúster de servidores) para mejorar el rendimiento y la seguridad. En uno pequeño, las tres pueden convivir en el mismo servidor.

### El Patrón MVC: El Chef, el Camarero y la Despensa

El **Modelo-Vista-Controlador (MVC)** no es una arquitectura en sí, sino un patrón de diseño de software que encaja perfectamente en la capa de negocio. Es la forma más popular de organizar el código para que no se convierta en un infierno de mantener.

- **Modelo:** Representa los datos. Es el único que sabe cómo hablar con la base de datos. Si el Controlador necesita un usuario, se lo pide al Modelo de usuarios.
- **Vista:** La interfaz de usuario. Es una plantilla "tonta" que se limita a mostrar los datos que le pasa el Controlador. No tiene lógica.
- **Controlador:** El director de orquesta. Recibe la petición del usuario, le pide al Modelo los datos que necesita, y cuando los tiene, elige una Vista y se los entrega para que los pinte.

```mermaid
    sequenceDiagram
    participant Usuario
    participant Controlador
    participant Modelo
    participant Vista

    Usuario->>Controlador: Petición (ej: /user/view/1)
    Controlador->>Modelo: Oye, dame el usuario con id 1
    Modelo->>Modelo: Consulto la Base de Datos...
    Modelo-->>Controlador: Aquí tienes los datos del usuario
    Controlador->>Vista: Toma estos datos y muéstrate
    Vista-->>Controlador: HTML generado
    Controlador-->>Usuario: Aquí tienes la página
```

#### Ejemplo Práctico en PHP (PSR-12)

Imagina una estructura de carpetas simple: `controllers/`, `models/`, `views/`, y un `index.php` que actúa como enrutador principal.

```php
// index.php (Enrutador Simple)

// Define la acción a realizar, por defecto 'home'
$action = $_GET['action'] ?? 'home';

// Decide qué controlador cargar
switch ($action) {
    case 'showUser':
        // Incluye y crea una instancia del controlador de usuarios
        require_once 'controllers/UserController.php';
        $controller = new UserController();
        // Llama al método para mostrar un usuario, pasando el ID
        $controller->show($_GET['id'] ?? 0);
        break;
    default:
        echo "<h1>Bienvenido a nuestra increíble App</h1><p>Página principal</p>";
}
```

```php
// controllers/UserController.php
<?php

// Incluimos el modelo para poder usarlo
require_once 'models/User.php';

class UserController
{
    /**
     * Muestra la información de un usuario específico.
     *
     * @param int $id El ID del usuario a buscar.
     */
    public function show(int $id): void
    {
        // Pide al modelo que encuentre al usuario
        $userModel = new User();
        $user = $userModel->find($id);

        // Si el usuario existe, carga la vista para mostrarlo.
        // Si no, muestra un error.
        if ($user) {
            // La vista tendrá acceso a la variable $user
            require 'views/user_detail_view.php';
        } else {
            // La vista de error podría ser más elaborada
            echo "Error 404: Usuario no encontrado.";
        }
    }
}
```

```php
// models/User.php
<?php

class User
{
    /**
     * Busca un usuario en la base de datos por su ID.
     *
     * En un caso real, aquí iría la lógica para conectar
     * a la BBDD (PDO, MySQLi) y ejecutar una consulta SQL.
     *
     * @param int $id El ID del usuario.
     * @return array|null Un array con los datos del usuario o null si no se encuentra.
     */
    public function find(int $id): ?array
    {
        // --- SIMULACIÓN DE ACCESO A BASE DE DATOS ---
        $database = [
            1 => ['name' => 'Gandalf', 'email' => 'gandalf@istari.com'],
            2 => ['name' => 'Aragorn', 'email' => 'strider@gondor.gov'],
        ];

        return $database[$id] ?? null;
        // --- FIN DE LA SIMULACIÓN ---
    }
}
```

```php
<!-- views/user_detail_view.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Usuario</title>
    <style>
        body { font-family: sans-serif; background-color: #f4f4f4; padding: 20px; }
        .card { background-color: white; border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="card">
        <!-- Usamos htmlspecialchars para prevenir ataques XSS. ¡Buena práctica! -->
        <h1><?php echo htmlspecialchars($user['name']); ?></h1>
        <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
    </div>
</body>
</html>
```

!!! tip "Frameworks: No reinventes la rueda"
    Hacer todo esto desde cero es genial para aprender, ¡pero en el mundo real el tiempo es oro! Herramientas como **Laravel** o **Symfony** (en PHP) ya te dan toda esta estructura MVC y mucho más, lista para usar. Son como un kit de cocina profesional que ya viene con los cuchillos afilados.

### El Arsenal del Desarrollador: ¿XAMPP o Docker?

Para poder ejecutar código PHP, necesitas un entorno de servidor.

```markmap

markmap:
  colorFreezeLevel: 2
  height: 800
  toolbar: true
  width: 1000

# Entorno de Servidor

## La Santísima Trinidad
- **Servidor Web**: Apache / Nginx
  - Escucha peticiones HTTP<br>y sirve archivos.
- **Intérprete de Lenguaje**: PHP
  - Ejecuta tu código<br>y genera el HTML.
- **Base de Datos**: MySQL / MariaDB
  - Almacena tus datos<br>de forma persistente.

## ¿Cómo lo instalo?
- **XAMPP / WAMP / MAMP**
  - **Pros**: Fácil y rápido de usar.<br>Un solo instalador<br>para todo.
  - **Contras**: Menos flexible.<br>Puede haber diferencias<br>con el entorno real.
- **Docker**
  - **Pros**: El estándar profesional.<br>Replica el entorno<br>de producción exactamente.
  - **Contras**: Curva de aprendizaje<br>un poco más alta.
  
  
```




!!! success "¡A por Docker!"
    Aunque XAMPP es más sencillo para una primera toma de contacto, en el mundo profesional **Docker es el rey**. Acostumbrarse a él desde el principio te dará una ventaja competitiva enorme. Es pasar de jugar con un coche de juguete a tener las llaves de un Fórmula 1.

---

## Aplicación en el Mundo Real

No creas que esto es solo teoría académica. Así funcionan las webs que usas cada día:

-   **Cualquier tienda online (Amazon, PCComponentes...):** Cuando ves un producto, un **Controlador** ha recibido tu petición. Ha preguntado al **Modelo** por los datos de ese producto (precio, stock, imágenes). El Modelo los ha sacado de una gigantesca base de datos. Finalmente, el Controlador ha pasado esos datos a una **Vista** para que veas la página del producto.
-   **Redes Sociales (Facebook, Instagram, X):** Tu *feed* de noticias es el ejemplo perfecto de una página dinámica. Un algoritmo (la **capa de negocio**) se ejecuta en el servidor para decidir qué posts mostrarte, basándose en tus amigos, tus gustos y la publicidad. Consulta la base de datos (la **capa de datos**) y te monta un HTML a medida.
-   **Sistemas de Gestión de Contenidos (CMS):** El rey de los CMS, **WordPress**, es una gigantesca aplicación PHP que sigue estos principios. Tiene un back-end (el panel de `wp-admin`, capa de negocio pura) donde se gestiona el contenido, y un front-end (la web pública, la capa de presentación) que muestra ese contenido dinámicamente desde la base de datos.

---

## Para Saber Más

¿Te has quedado con ganas de más? ¡Perfecto! La curiosidad es el motor de un buen desarrollador.

1.  [MDN Web Docs: Guía general sobre el lado del servidor](https://developer.mozilla.org/es/docs/Learn/Server-side/First_steps/Introduction): Una visión general fantástica del ecosistema del lado del servidor, explicada por una de las fuentes más fiables de la web.
2.  [FreeCodeCamp: What is MVC Architecture?](https://www.freecodecamp.org/news/model-view-controller-mvc-architecture-for-beginners/): Un artículo muy claro y con buenas analogías (en inglés) para afianzar el concepto de Modelo-Vista-Controlador.
3.  [PHP The Right Way](https://phptherightway.com/): No es un tutorial, sino una guía de buenas prácticas, arquitecturas y herramientas del ecosistema PHP moderno. Lectura obligatoria para cualquiera que se tome PHP en serio.