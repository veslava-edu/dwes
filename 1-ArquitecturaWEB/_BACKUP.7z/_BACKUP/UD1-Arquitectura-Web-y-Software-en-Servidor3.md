<!-- Nombre de archivo sugerido: T01-introduccion-programacion-servidor.md -->

# Tema 1: Introducción a la Programación en Entorno Servidor

¡Bienvenidos al *backstage* de la web! Hasta ahora, probablemente habéis trabajado mucho con lo que el usuario ve y toca: el HTML que estructura el contenido, el CSS que lo embellece y quizás algo de JavaScript para darle vida. Eso es el escenario, la parte visible del espectáculo. Pero la verdadera magia, la que hace que una tienda online funcione, que una red social te muestre las últimas noticias de tus amigos o que puedas ver tu correo electrónico, ocurre detrás del telón, en un lugar llamado **servidor**.

Imagina que la web es un restaurante gigante. Como usuario (el **cliente**), te sientas a la mesa con un menú (la interfaz de la página). Cuando pides un plato, el camarero (el **navegador**) lleva tu comanda a la cocina (el **servidor**).
*   Si pides algo sencillo y ya preparado, como una ensalada que está en la vitrina, el camarero te la trae directamente. Esto sería una **página estática**.
*   Pero si pides un chuletón al punto con patatas, el chef (un **programa en el servidor**, como PHP) tiene que ponerse a cocinar. Coge los ingredientes de la despensa (la **base de datos**), sigue una receta (la **lógica del programa**) y crea un plato único para ti. Cuando está listo, el camarero te lo sirve. Eso, compañeros, es una **página dinámica**.

En este tema, vamos a abrir las puertas de esa cocina. Aprenderemos cómo funciona, qué herramientas usa el chef y cómo podemos empezar a escribir nuestras propias "recetas" para crear aplicaciones web potentes y dinámicas. ¡Poneos el delantal, que empezamos!

## Conceptos Fundamentales

Antes de encender los fogones, necesitamos conocer nuestro equipo y nuestro vocabulario. Estos son los términos que usarás a diario en el desarrollo back-end.

!!! note "Definición: Cliente"
    Es quien inicia la conversación. En el 99% de los casos, es el **navegador web** (Chrome, Firefox, Safari...) que una persona utiliza en su ordenador, tablet o móvil. El cliente es el que tiene una necesidad (ver un producto, leer un artículo, enviar un mensaje) y realiza una **petición** para satisfacerla.

!!! note "Definición: Servidor"
    Es el "cerebro" de la operación, aunque en realidad es un **programa** muy potente que se ejecuta en un ordenador que está conectado a internet 24/7. Su único trabajo es escuchar peticiones de los clientes, procesarlas y enviar una **respuesta**. Por extensión, también llamamos servidor a la máquina física donde se ejecuta este programa.

!!! note "Definición: Protocolo HTTP"
    Es el idioma oficial que hablan clientes y servidores para entenderse. Es un conjunto de reglas que definen cómo se debe formular una petición (ej: `GET /dame/esta/pagina`) и cómo debe ser una respuesta (ej: `200 OK`, aquí tienes el HTML). Sin HTTP, la comunicación sería un caos.

!!! note "Definición: Página Estática"
    Es como un folleto en PDF. Su contenido está predefinido en un archivo HTML y es exactamente el mismo para todos los usuarios que la visitan. No cambia a menos que un desarrollador edite el archivo manualmente. Son rápidas y sencillas, pero muy limitadas.

!!! note "Definición: Página Dinámica"
    Es una página "viva", generada al momento por el servidor. Su contenido se adapta en función de quién la pide, qué hora es, o qué acciones ha realizado el usuario. El servidor ejecuta un programa (un *script*) que consulta bases de datos o servicios externos para construir un HTML a medida y enviárselo al cliente.

## Desarrollo y Ejemplos Prácticos

### La Arquitectura Cliente-Servidor: La Columna Vertebral de la Web

El modelo cliente-servidor es el pilar sobre el que se construye toda la web. Es un diálogo constante de petición y respuesta.

1.  **Petición (Request)**: El usuario escribe `www.amazon.es` en su navegador (el cliente) y pulsa Enter. El navegador crea una petición HTTP que, en esencia, dice: "¡Eh, servidor de Amazon! Dame tu página principal". Esta petición viaja por internet hasta llegar al ordenador correcto.
2.  **Procesamiento**: El servidor de Amazon recibe la petición. No tiene una "página principal" guardada. En su lugar, ejecuta un programa. Este programa mira quién eres, tu historial, las ofertas del día, los productos más vendidos y, con toda esa información (que saca de una base de datos), construye una página HTML única para ti.
3.  **Respuesta (Response)**: Una vez que el HTML está listo, el servidor lo empaqueta en una respuesta HTTP y se lo envía de vuelta a tu navegador.
4.  **Renderizado**: Tu navegador recibe el HTML y lo "pinta" en la pantalla para que puedas verlo.

Este proceso, que ocurre en milisegundos, se puede visualizar con un diagrama de secuencia:

```mermaid
sequenceDiagram
    participant Cliente (Navegador)
    participant Servidor Web (Apache)
    participant Intérprete PHP
    participant Servidor BBDD (MySQL)

    Cliente->>Servidor Web: Petición HTTP GET /mi_perfil.php
    Servidor Web->>Intérprete PHP: ¡Ejecuta mi_perfil.php!
    Intérprete PHP->>Servidor BBDD: Dame los datos del usuario 'Ana'
    Servidor BBDD-->>Intérprete PHP: Aquí tienes: {nombre: 'Ana', ...}
    Intérprete PHP-->>Servidor Web: Proceso terminado. Aquí está el HTML generado.
    Servidor Web-->>Cliente: Respuesta HTTP 200 OK con el HTML
```

!!! question "Ejercicio de Reflexión"
    1.  Cuando usas la app de Spotify en tu móvil para escuchar una canción, ¿quién es el cliente y quién es el servidor?
    2.  Piensa en Discord. ¿Qué arquitectura crees que utiliza para mostrar los mensajes de un canal? ¿Y para una videollamada entre dos personas?
    3.  El aula virtual que usas (Moodle, Aules, etc.), ¿es una aplicación cliente-servidor? ¿Por qué?

### ¿Código en el Cliente o en el Servidor? El Dónde lo Cambia Todo

Una de las confusiones más comunes al empezar es entender qué código se ejecuta y dónde. La respuesta lo cambia todo.

| Característica | Código en el Cliente (Front-End) | Código en el Servidor (Back-End) |
| :--------------- | :--------------------------------- | :----------------------------------- |
| **Lenguaje** | JavaScript (principalmente) | **PHP**, Python, Java, Node.js, etc. |
| **¿Dónde se ejecuta?** | En el navegador del usuario | En el ordenador del servidor |
| **Propósito** | Interactividad, animaciones, UX | Acceso a datos, lógica de negocio |
| **Ejemplo** | Validar que un email tiene formato `...@...` antes de enviar el formulario. | Comprobar en la BBDD si ese email ya está registrado. |

**El Back-End es el guardián de la verdad.** El cliente (navegador) no es un entorno seguro. Un usuario con conocimientos puede manipular el código JavaScript que se ejecuta en su máquina. Por tanto, toda operación crítica (comprobar un pago, guardar datos, verificar una contraseña) **DEBE** realizarse en el servidor.

Veamos nuestro primer "Hola Mundo" en PHP. Fíjate cómo el código PHP está incrustado dentro del HTML.

```php
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejemplo Back-End</title>
</head>
<body>
    <h1>Mi primera página dinámica</h1>
    <p>
        Esto es HTML normal, que se envía tal cual.
        Pero ahora, vamos a pedirle al servidor que nos diga la hora:
        <strong>
            <?php
                // Esta parte solo la ve y la ejecuta el servidor.
                // El navegador del usuario nunca verá este código.
                echo "¡Hola! Son las " . date('H:i:s');
            ?>
        </strong>
    </p>
</body>
</html>
```

!!! tip "El Perfil Full-Stack: El Héroe Completo"
    En las ofertas de trabajo, verás mucho el término "Full-Stack Developer". Se refiere a un profesional que domina tanto el Front-End como el Back-End. Es alguien que puede diseñar la carrocería del coche y también construir el motor. Son perfiles muy valorados porque tienen una visión completa del proyecto.

!!! question "Ejercicio de Reflexión"
    1.  Quieres comprobar que la contraseña que un usuario introduce en un formulario de registro tiene al menos 8 caracteres. ¿Lo harías en el Front-end, en el Back-end o en ambos? Justifica tu respuesta.
    2.  Una tienda online quiere mostrar un 10% de descuento en todos los productos solo durante el Black Friday. ¿Dónde implementarías esa lógica de decisión? ¿Por qué?
    3.  ¿Por qué no es buena idea que el código JavaScript del cliente contenga la contraseña para acceder a la base de datos?

### Más Allá de Dos: La Arquitectura de Tres Capas

A medida que las aplicaciones crecen, el modelo cliente-servidor se expande a una estructura más organizada conocida como **arquitectura de tres capas lógicas**. Es una forma de organizar el código para que sea más mantenible, escalable y seguro. Piensa en ello como los diferentes departamentos de una empresa.

1.  **Capa de Presentación (Vista)**: Es todo lo que el usuario ve y con lo que interactúa. Su única misión es mostrar datos y capturar las acciones del usuario. En la web, esto es el HTML, CSS y JavaScript que se ejecuta en el navegador. Es el departamento de marketing y ventas.

2.  **Capa de Negocio (Lógica o Controlador)**: Es el cerebro. Contiene toda la lógica de la aplicación. Recibe las peticiones de la capa de presentación, procesa los datos, aplica las reglas del negocio ("si el usuario es premium, dale acceso") y se comunica con la capa de datos para obtener o guardar información. Aquí es donde vive nuestro código PHP. Es el departamento de operaciones.

3.  **Capa de Datos (Persistencia o Modelo)**: Es el almacén de la empresa. Su única responsabilidad es guardar y recuperar información de forma segura y eficiente, normalmente desde una base de datos (como MySQL). No sabe nada de lógica de negocio ni de cómo se van a mostrar los datos. Es el departamento de archivo y almacén.


<div class="center">
```mermaid
graph TD
    A[Usuario con Navegador Web] -->|Petición HTTP| B["Servidor Web (PHP, Lógica)"]
    B -->|Consulta SQL| C["Servidor de BBDD (MySQL)"]
    C -->|Resultados| B
    B -->|Respuesta HTML| A

    subgraph "Capa de Presentación (Vista)"
    A
    end
    subgraph "Capa de Negocio (Lógica)"
    B
    end
    subgraph "Capa de Datos (Persistencia)"
    C
    end
```
</div>

!!! danger "¡A cada capa lo suyo!"
    Nunca, jamás, accedas a la base de datos directamente desde la capa de presentación. Es una brecha de seguridad garrafal y una pésima práctica de organización. Cada capa debe hablar únicamente con sus capas adyacentes.

!!! question "Ejercicio de Reflexión"
    1.  Mapea las tres capas a una aplicación que conozcas bien, como Twitter. ¿Qué parte sería la capa de presentación, cuál la de negocio y cuál la de datos?
    2.  Si tuvieras que añadir una nueva funcionalidad, como un sistema de "me gusta", ¿en qué capa(s) tendrías que escribir código?
    3.  ¿Qué ventajas crees que tiene separar el código en estas tres capas en un equipo donde trabajan varios programadores?

### Montando tu Laboratorio: El Entorno de Desarrollo

Para empezar a programar en el servidor, no necesitas un superordenador. Lo que necesitas es simular un entorno de servidor en tu propia máquina. A esto se le llama trabajar en **local**.

La "Santísima Trinidad" del desarrollo web con PHP es el stack **LAMP**:
*   **L**inux: El sistema operativo del servidor (aunque en local puedes usar **W**indows (WAMP) o **M**ac (MAMP)).
*   **A**pache: El programa servidor web más popular y veterano. Es el que gestiona las peticiones HTTP.
*   **M**ySQL/MariaDB: El sistema gestor de bases de datos. Nuestro almacén.
*   **P**HP: El lenguaje de programación. El cerebro que genera la lógica.

```markmap
 ---
markmap:
    maxWidth: 800
    colorFreezeLevel: 2
---
# Entorno de Servidor

## La Santísima Trinidad
- **Servidor Web**: Apache / Nginx
- **Intérprete de Lenguaje**: PHP
- **Base de Datos**: MySQL / MariaDB

## ¿Cómo lo instalo?
- **XAMPP / WAMP / MAMP**
  - **Pros**: Fácil y rápido.<br>Un solo instalador para todo.
  - **Contras**: Menos flexible.<br>La versión de los componentes<br>es fija.
- **Docker**
  - **Pros**: El estándar profesional.<br>Replica el entorno de producción<br>exactamente.
  - **Contras**: Requiere un<br>aprendizaje inicial.
```

!!! tip "XAMPP para empezar, Docker para triunfar"
    Para empezar en el curso, una herramienta como **XAMPP** es perfecta. Es un paquete que te instala y configura Apache, MySQL y PHP con un solo clic. Es sencillo y te permite centrarte en aprender a programar. Más adelante, aprenderás a usar **Docker**, que es la herramienta estándar en la industria para crear entornos de desarrollo aislados y consistentes.

!!! question "¡Manos a la obra!"
    1.  Busca, descarga e instala XAMPP desde su [página oficial](https://www.apachefriends.org/es/index.html).
    2.  Una vez instalado, arranca los módulos de Apache y MySQL desde el panel de control de XAMPP.
    3.  Busca la carpeta `htdocs` dentro de tu instalación de XAMPP. Este es el directorio raíz de tu servidor web local. Todo lo que pongas aquí será accesible desde el navegador.
    4.  Crea un archivo llamado `info.php` dentro de `htdocs` con este contenido: `<?php phpinfo(); ?>`.
    5.  Abre tu navegador y visita `http://localhost/info.php`. ¿Qué información puedes ver? Anota la versión de PHP, y la ruta del archivo `php.ini` cargado.

## Aplicación en el Mundo Real

Esta arquitectura no es solo teoría académica. Es el motor que impulsa a gigantes de internet y a la mayoría de las aplicaciones con las que interactúas.

*   **WordPress**: El Sistema de Gestión de Contenidos (CMS) más usado del mundo, que da vida a más del 40% de toda la web, está construido sobre un stack LAMP clásico (PHP y MySQL). Cada vez que lees un blog, ves una noticia o compras en una pequeña tienda online, es muy probable que un servidor esté ejecutando código PHP para ti.
*   **Facebook (Meta)**: Aunque su arquitectura es ahora inmensamente compleja, Facebook se construyó originalmente sobre PHP. De hecho, para escalar su rendimiento, crearon su propio compilador de PHP y una nueva versión del lenguaje llamada Hack. Demuestra la potencia y escalabilidad que puede alcanzar esta tecnología.
*   **E-commerce (Magento, PrestaShop, WooCommerce)**: Las grandes plataformas de comercio electrónico de código abierto son aplicaciones PHP increíblemente sofisticadas. Gestionan catálogos de productos, carritos de la compra, pasarelas de pago y cuentas de usuario, todo ello a través de la lógica ejecutada en el servidor.

Aprender a programar en el lado del servidor es aprender a construir el núcleo funcional de cualquier aplicación web interactiva.

## Para Saber Más

Para profundizar en estos conceptos fundamentales, te recomiendo encarecidamente estos recursos:

1.  **Manual oficial de PHP**: La fuente de toda sabiduría. Siempre que tengas una duda sobre una función, aquí está la respuesta. [https://www.php.net/manual/es/](https://www.php.net/manual/es/)
2.  **MDN Web Docs - Módulo del lado del cliente y del lado del servidor**: Una excelente explicación de la Mozilla Developer Network sobre las diferencias y la interacción entre ambos mundos. [https://developer.mozilla.org/es/docs/Learn/Server-side/First_steps/Client-side_and_server-side](https://developer.mozilla.org/es/docs/Learn/Server-side/First_steps/Client-side_and_server-side)
3.  **Video: "¿Qué es un Servidor Web?" (Nate Gentile)**: Un video muy didáctico y visual que explica de forma clara y amena qué es y cómo funciona un servidor, no solo a nivel de software sino también de hardware. [https://www.youtube.com/watch?v=K2Z5p9K4i-o](https://www.youtube.com/watch?v=K2Z5p9K4i-o)