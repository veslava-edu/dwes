<!-- Nombre de archivo sugerido: T01_Ejercicios_Arquitectura-Web-y-Software-en-Servidor.md -->

# Proyecto "Nexus Intranet": Ejercicios de Arquitectura Web

¡Hola, equipo! Bienvenidos a Innovatech Solutions. Como nuestro nuevo equipo de desarrollo, vuestra primera misión es clave para el futuro de la comunicación interna de la empresa: **construir los cimientos de "Nexus", nuestra nueva intranet corporativa**. Este portal será el corazón digital de Innovatech, un lugar para noticias, un directorio de empleados, gestión de eventos y mucho más.

En esta primera fase, nos centraremos en aplicar los conceptos fundamentales de la arquitectura web. No construiremos la aplicación completa, sino que desarrollaremos prototipos y módulos clave para asegurarnos de que la base (la arquitectura) es sólida, profesional y escalable. Cada ejercicio es un paso para construir un componente de "Nexus". ¡Manos a la obra!

## Ejercicios de Consolidación

Aquí sentaremos las bases. Estos ejercicios están diseñados para asegurar que todos compartimos un mismo entendimiento de los conceptos clave antes de construir componentes más complejos.

!!! success "Ejercicio de Consolidación | Dificultad: Baja"
    #### 1. Diagnóstico de Arquitectura: El Glosario de Innovatech
    **Objetivo:** Validar la comprensión de los términos fundamentales de la arquitectura web (Cliente, Servidor, Estático vs. Dinámico, Arquitectura Cliente-Servidor).
    **Tarea a Realizar:** Responde a las siguientes preguntas basándote en el material didáctico y tu propia investigación. Sé conciso y claro, como si se lo explicaras a un nuevo becario del departamento de marketing.
    1.  Si un empleado usa Chrome en su portátil para acceder a Nexus, ¿qué rol juega Chrome en la arquitectura cliente-servidor?
    2.  Cuando Nexus muestre una página con las ofertas de menú del día de la cafetería, que cambian cada día, ¿será una página estática o dinámica? Justifica tu respuesta.
    3.  Describe con tus propias palabras el flujo de una petición HTTP cuando un usuario solicita ver su perfil personalizado en la intranet Nexus. ¿Quién "cocina" la respuesta?
    4.  En la arquitectura de 3 capas de Nexus, ¿qué capa sería la responsable de conectarse a la base de datos para obtener la lista de empleados?
    **Aplicación en el Mundo Real:** Este conocimiento es la base de cualquier conversación técnica en un equipo de desarrollo. Usar los términos correctamente evita malentendidos y demuestra profesionalidad al discutir cómo implementar nuevas funcionalidades.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    1.  **Rol de Chrome:** Chrome actúa como el **Cliente**. Es el software que inicia la petición para obtener la página web de la intranet.
    2.  **Menú del día:** Sería una **página dinámica**. Aunque el contenido no es personalizado por usuario, cambia con el tiempo (diariamente). El servidor necesita ejecutar un script (ej. en PHP) para leer el menú de hoy (desde una base de datos o un fichero) y generar el HTML correspondiente. Una página estática sería la misma para todos, siempre.
    3.  **Flujo de perfil personalizado:**
        *   El **Cliente** (navegador) envía una petición HTTP (ej: `GET /perfil.php`).
        *   El **Servidor Web** recibe la petición. Ve que es un fichero `.php` y se lo pasa al intérprete de PHP.
        *   El script PHP (la **Capa de Negocio**) se ejecuta. Probablemente, se conecte a la **Capa de Datos** (base de datos) para buscar la información del usuario que ha iniciado sesión.
        *   Con los datos obtenidos, PHP "construye" un documento HTML a medida.
        *   El Servidor Web envía ese HTML generado como respuesta al Cliente.
        *   El Cliente (navegador) renderiza el HTML para que el usuario lo vea.
        El que "cocina" la respuesta es el **servidor**, específicamente el software del lado del servidor (el intérprete de PHP en este caso).
    4.  **Capa responsable de los datos:** La **Capa de Datos** (o de Persistencia) es la única responsable de interactuar con la base de datos.
    </details>

!!! success "Ejercicio de Consolidación | Dificultad: Baja"
    #### 2. Dinamizando el Saludo de Bienvenida
    **Objetivo:** Convertir una parte de una página estática en contenido dinámico usando PHP para mostrar información generada por el servidor.
    **Setup Inicial:**
    1.  Necesitarás un entorno de desarrollo local con PHP y un servidor web (como XAMPP, WAMP, MAMP o el servidor integrado de PHP).
    2.  Crea una carpeta en tu ordenador llamada `nexus-project`. Dentro, crea un fichero llamado `index.php`.
    **Tarea a Realizar:**
    1.  Edita el fichero `index.php` para que contenga una página de bienvenida estática.
        *   El título (`<title>`) debe ser "Bienvenido a Nexus Intranet".
        *   Debe tener un encabezado `<h1>` que diga "Nexus: Conectando Innovatech Solutions".
    2.  Debajo del encabezado, añade un nuevo párrafo.
    3.  En lugar de texto estático, dentro de este párrafo vas a insertar un bloque de código PHP que imprima la fecha y hora actual del servidor. Utiliza la función `date()` de PHP que se muestra en el material de referencia.
    4.  Asegúrate de que puedes servir este fichero desde tu servidor local y verlo en el navegador (ej: `http://localhost/nexus-project/`). El resultado final debería mostrar el saludo y, debajo, un mensaje como: "Hora del servidor: 2025-07-25 16:30:00".
    **Aplicación en el Mundo Real:** Esta es la forma más básica de contenido dinámico. Se usa en todas partes: para mostrar la hora, desear "buenos días" o "buenas tardes" según el momento del día, o para personalizar un saludo con el nombre del usuario que ha iniciado sesión.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    ```html+php
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenido a Nexus Intranet</title>
    </head>
    <body>
        <h1>Nexus: Conectando Innovatech Solutions</h1>
        
        <!-- Contenido dinámico añadido -->
        <p>
            <?php
                echo "Hora del servidor: " . date('Y-m-d H:i:s');
            ?>
        </p>
    </body>
    </html>
    ```
    </details>

## Ejercicios de Refuerzo

Ahora que los cimientos están puestos, vamos a construir nuestros primeros módulos para la intranet "Nexus". Este ejercicio te guiará paso a paso.

!!! warning "Ejercicio de Refuerzo | Dificultad: Media"
    #### 3. Módulo de Noticias: Construyendo la Vista
    **Objetivo:** Crear la capa de presentación (Vista) para un componente dinámico, conectándola con datos proporcionados por el backend.
    **Setup Inicial:**
    1.  Crea un fichero llamado `noticias.php` en tu proyecto.
    2.  Pega el siguiente código al principio del fichero. Este código simula ser nuestro **Controlador** y **Modelo**, que ya han hecho su trabajo de obtener las noticias. Tu tarea es construir la parte de la **Vista**.
    ```php
    <?php
    // --- SIMULACIÓN DEL CONTROLADOR Y MODELO ---
    // En un sistema MVC real, esto estaría en ficheros separados.
    
    // El "Modelo" obtiene los datos (simulados en un array)
    function obtener_noticias() {
        return [
            [
                'titulo' => 'Lanzamiento de la nueva versión de Innovatec OS',
                'fecha' => '2025-07-22',
                'autor' => 'Equipo de Producto'
            ],
            [
                'titulo' => 'Resultados del Q2: Crecimiento récord',
                'fecha' => '2025-07-20',
                'autor' => 'Departamento Financiero'
            ],
            [
                'titulo' => 'Próximo evento: Barbacoa de verano',
                'fecha' => '2025-07-18',
                'autor' => 'Recursos Humanos'
            ]
        ];
    }
    
    // El "Controlador" llama al modelo y prepara los datos para la vista.
    $lista_noticias = obtener_noticias();
    
    // --- FIN DE LA SIMULACIÓN DEL BACKEND ---
    
    // AHORA EMPIEZA TU TRABAJO: LA VISTA
    ?>
    ```
    **Tarea a Realizar:**
    1.  Justo debajo del código PHP proporcionado, escribe la estructura HTML de la página de noticias.
    2.  Debe tener un título `<h1>` que diga "Últimas Noticias de Innovatech".
    3.  Debajo del título, crea una sección para mostrar las noticias.
    4.  Utiliza un bucle `foreach` de PHP para iterar sobre la variable `$lista_noticias`.
    5.  Dentro del bucle, por cada noticia, debes imprimir en HTML:
        *   Un encabezado `<h2>` con el título de la noticia.
        *   Un párrafo `<p>` que contenga la fecha y el autor. Por ejemplo: "Publicado el 2025-07-22 por Equipo de Producto".
    **Pista:** Dentro del bucle `foreach ($lista_noticias as $noticia)`, cada `$noticia` será un array asociativo. Podrás acceder a sus valores con `$noticia['titulo']`, `$noticia['fecha']`, etc.
    **Aplicación en el Mundo Real:** Esta es la tarea más común de un desarrollador que trabaja con un CMS o un framework: recibir un conjunto de datos del backend y maquetarlos en una plantilla (la Vista) para que el usuario final los vea formateados y ordenados.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>
    
    ```html+php
    <?php
    // --- SIMULACIÓN DEL CONTROLADOR Y MODELO ---
    // En un sistema MVC real, esto estaría en ficheros separados.
    
    // El "Modelo" obtiene los datos (simulados en un array)
    function obtener_noticias() {
        return [
            [
                'titulo' => 'Lanzamiento de la nueva versión de Innovatec OS',
                'fecha' => '2025-07-22',
                'autor' => 'Equipo de Producto'
            ],
            [
                'titulo' => 'Resultados del Q2: Crecimiento récord',
                'fecha' => '2025-07-20',
                'autor' => 'Departamento Financiero'
            ],
            [
                'titulo' => 'Próximo evento: Barbacoa de verano',
                'fecha' => '2025-07-18',
                'autor' => 'Recursos Humanos'
            ]
        ];
    }
    
    // El "Controlador" llama al modelo y prepara los datos para la vista.
    $lista_noticias = obtener_noticias();
    
    // --- FIN DE LA SIMULACIÓN DEL BACKEND ---
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Noticias - Nexus</title>
    </head>
    <body>
        <h1>Últimas Noticias de Innovatech</h1>

        <?php foreach ($lista_noticias as $noticia): ?>
            <article>
                <h2><?php echo htmlspecialchars($noticia['titulo']); ?></h2>
                <p>
                    Publicado el <?php echo htmlspecialchars($noticia['fecha']); ?> 
                    por <strong><?php echo htmlspecialchars($noticia['autor']); ?></strong>
                </p>
            </article>
            <hr>
        <?php endforeach; ?>

    </body>
    </html>
    ```
    *Nota: Se ha añadido `htmlspecialchars()` como buena práctica de seguridad para prevenir ataques XSS, aunque no se pedía explícitamente en el ejercicio.*
    </details>

## Ejercicios de Ampliación

Es hora de afrontar un reto más complejo y abierto. Este ejercicio requiere iniciativa, la aplicación de los conceptos en un escenario realista y la revisión del trabajo de un compañero.

!!! danger "Ejercicio de Ampliación | Dificultad: Alta"
    #### 4. Refactorizando a MVC: El Módulo de Eventos
    **Objetivo:** Reestructurar ("refactorizar") un script con "código espagueti" a una arquitectura MVC limpia, demostrando la habilidad para mejorar código existente.
    **Setup Inicial:**
    1.  Crea un fichero llamado `eventos_legacy.php`.
    2.  Pega el siguiente código "legacy" (heredado y desordenado):
    ```php
    <?php
    // eventos_legacy.php - ¡CÓDIGO ESPAGUETI!
    
    // Conexión a BBDD (simulada) y obtención de datos
    $eventos_raw = [
        ['id' => 10, 'nombre' => 'Hackathon Interno', 'fecha' => '2025-08-15', 'plazas' => 50, 'inscritos' => 48],
        ['id' => 11, 'nombre' => 'Charla: Novedades en PHP 8.4', 'fecha' => '2025-08-22', 'plazas' => 100, 'inscritos' => 95],
        ['id' => 12, 'nombre' => 'Taller de Docker', 'fecha' => '2025-09-01', 'plazas' => 20, 'inscritos' => 20],
    ];
    
    // Lógica de negocio: calcular plazas disponibles y añadir un estado
    $eventos_procesados = [];
    foreach ($eventos_raw as $evento) {
        $evento['plazas_disponibles'] = $evento['plazas'] - $evento['inscritos'];
        if ($evento['plazas_disponibles'] <= 0) {
            $evento['estado'] = 'Completo';
        } elseif ($evento['plazas_disponibles'] < 10) {
            $evento['estado'] = 'Últimas plazas';
        } else {
            $evento['estado'] = 'Disponible';
        }
        $eventos_procesados[] = $evento;
    }
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head><title>Eventos Corporativos</title></head>
    <body>
        <h1>Próximos Eventos en Innovatech</h1>
        <?php foreach ($eventos_procesados as $evento): ?>
            <div style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px;">
                <h2><?php echo htmlspecialchars($evento['nombre']); ?></h2>
                <p>Fecha: <?php echo $evento['fecha']; ?></p>
                <p><strong>Estado: <?php echo htmlspecialchars($evento['estado']); ?></strong></p>
                <p>Plazas disponibles: <?php echo $evento['plazas_disponibles']; ?></p>
            </div>
        <?php endforeach; ?>
    </body>
    </html>
    ```    **Tarea a Realizar:**
    1.  Crea una nueva estructura de ficheros para una implementación MVC. Como mínimo, necesitarás un `modelo.php`, una `vista.php` y un `controlador.php`.
    2.  **Refactoriza el código:** Mueve las responsabilidades del fichero `eventos_legacy.php` a su lugar correspondiente en la nueva estructura:
        *   **Modelo:** Debe tener una función que devuelva los datos crudos de los eventos (el array `$eventos_raw`).
        *   **Controlador:** Debe:
            *   Llamar al Modelo para obtener los eventos.
            *   Contener la lógica de negocio (el bucle que calcula las plazas disponibles y el estado).
            *   Pasar los datos ya procesados a la Vista.
        *   **Vista:** Debe contener únicamente el HTML y el bucle de presentación que recorre los datos procesados que le pasa el Controlador. Debe ser "tonta", sin cálculos.
    3.  El punto de entrada para ver el resultado debe ser tu `controlador.php`, y el resultado visual debe ser idéntico al del script original.
    
    ---
    **Tarea de Revisión por Pares (Peer Review):**
    1.  Intercambia tu código (los tres ficheros MVC) con un compañero.
    2.  Revisa el trabajo de tu compañero y dale feedback constructivo basándote en esta lista:
        *   **Separación de Responsabilidades:** ¿Está cada pieza de código en su fichero correcto? ¿La vista contiene lógica de negocio? ¿El modelo hace algo más que proporcionar datos?
        *   **Claridad del Código:** ¿El código es fácil de leer y entender? ¿Los nombres de las variables son descriptivos?
        *   **Funcionalidad:** ¿El `controlador.php` produce el resultado final esperado correctamente?

    **Aplicación en el Mundo Real:** La refactorización es una tarea constante en el desarrollo de software. Las empresas tienen sistemas antiguos ("legacy") que necesitan ser modernizados para que sean más fáciles de mantener, probar y escalar. Saber cómo desenredar "código espagueti" y ordenarlo en una arquitectura limpia es una habilidad muy valorada.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    **`modelo.php`**
    ```php
    <?php // modelo.php
    
    // El Modelo es responsable únicamente de la interacción con la capa de datos.
    // Su trabajo es obtener y/o guardar información.
    function get_eventos_desde_bd() {
        // Simula la obtención de datos crudos desde la base de datos.
        return [
            ['id' => 10, 'nombre' => 'Hackathon Interno', 'fecha' => '2025-08-15', 'plazas' => 50, 'inscritos' => 48],
            ['id' => 11, 'nombre' => 'Charla: Novedades en PHP 8.4', 'fecha' => '2025-08-22', 'plazas' => 100, 'inscritos' => 95],
            ['id' => 12, 'nombre' => 'Taller de Docker', 'fecha' => '2025-09-01', 'plazas' => 20, 'inscritos' => 20],
        ];
    }
    ```

    **`controlador.php`**
    ```php
    <?php // controlador.php
    
    // El Controlador actúa como director de orquesta. No contiene HTML ni acceso directo a BBDD.
    // 1. Incluye las dependencias que necesita (el modelo).
    require_once 'modelo.php';
    
    // 2. Pide los datos al Modelo.
    $eventos_raw = get_eventos_desde_bd();
    
    // 3. Ejecuta la lógica de negocio (cálculos, validaciones, etc.).
    $eventos_procesados = [];
    foreach ($eventos_raw as $evento) {
        $evento['plazas_disponibles'] = $evento['plazas'] - $evento['inscritos'];
        if ($evento['plazas_disponibles'] <= 0) {
            $evento['estado'] = 'Completo';
        } elseif ($evento['plazas_disponibles'] < 10) {
            $evento['estado'] = 'Últimas plazas';
        } else {
            $evento['estado'] = 'Disponible';
        }
        $eventos_procesados[] = $evento;
    }
    
    // 4. Pasa los datos procesados a la Vista para que los muestre.
    // La variable $eventos estará disponible en el fichero 'vista.php'.
    $eventos = $eventos_procesados;
    require 'vista.php';
    ```

    **`vista.php`**
    ```php
    <?php // vista.php ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Eventos Corporativos</title>
    </head>
    <body>
        <h1>Próximos Eventos en Innovatech</h1>
        
        <!-- La Vista es "tonta". Solo recibe datos y los muestra. No realiza cálculos. -->
        <?php foreach ($eventos as $evento): ?>
            <div style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px;">
                <h2><?php echo htmlspecialchars($evento['nombre']); ?></h2>
                <p>Fecha: <?php echo $evento['fecha']; ?></p>
                <p><strong>Estado: <?php echo htmlspecialchars($evento['estado']); ?></strong></p>
                <p>Plazas disponibles: <?php echo $evento['plazas_disponibles']; ?></p>
            </div>
        <?php endforeach; ?>
    </body>
    </html>
    ```
    </details>