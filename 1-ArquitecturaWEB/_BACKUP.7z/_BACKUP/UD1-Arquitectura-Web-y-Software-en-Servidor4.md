<!-- Nombre de archivo sugerido: T01-arquitectura-web-y-software-en-servidor.md -->

# UD1: Arquitecturas Web y el Software del Servidor

¡Hola, equipo! Bienvenidos a la primera unidad de Desarrollo en Entorno Servidor. Si en cursos anteriores habéis sido los arquitectos de lo que el usuario ve y toca (el *front-end*), ahora vamos a levantar el capó para entender y construir el motor que lo hace todo posible.

Para empezar, usemos una analogía que nos va a servir durante todo el curso: **montar una aplicación web es como gestionar un restaurante de éxito.**

Imagina un restaurante. Tienes:
1.  **El Cliente (El Comensal)**: Es la persona que llega, se sienta y tiene una necesidad: comer. Revisa la carta (la interfaz de la web) y hace un pedido.
2.  **El Servidor (El Camarero)**: Es el intermediario. No cocina, pero es el que toma nota del pedido del cliente (la *petición*), la lleva a la cocina y, cuando está lista, le trae el plato a la mesa (la *respuesta*).
3.  **La Cocina (El Back-end)**: Es donde ocurre la magia. Aquí los chefs (los programas, la lógica de negocio) reciben la orden, consultan la despensa (la *base de datos*) para ver si tienen ingredientes, preparan el plato y se lo entregan al camarero.

En esta unidad, vamos a estudiar el mapa completo del restaurante. Entenderemos quién es quién, cómo se comunican y qué necesitamos para construir nuestra propia "cocina" digital. ¡Vamos a encender los fogones!

## Conceptos Fundamentales

Antes de ponernos a picar código, tenemos que hablar el mismo idioma. Aquí tienes los términos clave que son el pan de cada día en el desarrollo web.

!!! note "Definición: Cliente"
    Es quien inicia la comunicación. En el 99% de los casos, será un **navegador web** (Chrome, Firefox, Safari...) ejecutándose en el ordenador o móvil de un usuario. Es el que tiene una necesidad y *pide* algo. Pero ojo, un cliente también podría ser una app móvil, un programa de escritorio o incluso otro servidor.

!!! note "Definición: Servidor"
    Es el que está a la escucha, esperando peticiones para satisfacerlas. Es un programa (o un conjunto de programas) que se ejecuta en un ordenador potente, siempre conectado a internet. Su trabajo es recibir una petición, procesarla (hacer cálculos, buscar en una base de datos, etc.) y devolver un resultado. Por extensión, también llamamos "servidor" a la máquina física donde se ejecuta ese programa.

!!! note "Definición: Protocolo HTTP"
    *Hypertext Transfer Protocol*. Es el **idioma** o el conjunto de reglas que el cliente y el servidor usan para entenderse. Define cómo deben ser los mensajes de petición ("¡Oye, quiero esta página!") y los de respuesta ("¡Claro, aquí la tienes!"). Funciona sobre TCP/IP, las autopistas de la información que estudiasteis en redes.

!!! note "Definición: Página Web Estática"
    Imagina un folleto en PDF. Es un documento que se creó una vez y siempre es el mismo para todo el que lo abre. Una página estática (hecha con HTML y CSS) es igual: el servidor la tiene guardada y, cuando un cliente la pide, se la envía tal cual. Su contenido no cambia a no ser que un desarrollador edite el fichero a mano.

!!! note "Definición: Página Web Dinámica"
    Es una página "viva". No existe como un fichero predefinido, sino que **se genera al momento** en el servidor justo cuando el cliente la pide. El servidor ejecuta un programa (por ejemplo, en PHP) que puede consultar una base de datos, tener en cuenta la hora que es o saber qué usuario ha iniciado sesión. El resultado de ese programa es un HTML único para esa petición. Tu feed de Instagram, los productos de Amazon o los resultados de una búsqueda en Google son páginas dinámicas.

<br><br><hr/><br><br>

## El Baile Cliente-Servidor: ¿Quién Pide y Quién Responde?

El corazón de la web es una conversación constante, un tango perfectamente coreografiado entre el cliente y el servidor. Este proceso se conoce como el ciclo de **petición-respuesta** (Request-Response).

1.  **La Petición (Request)**: El cliente (tu navegador) envía un mensaje al servidor. Este mensaje, formateado según el protocolo HTTP, contiene principalmente:
    *   **URL**: La dirección exacta del recurso que quiere (`/usuarios/perfil.php`).
    *   **Método**: La intención del cliente. Los más comunes son `GET` (para pedir datos) y `POST` (para enviar datos, como un formulario).
    *   **Cabeceras (Headers)**: Metadatos sobre la petición (qué navegador usas, qué formatos de respuesta aceptas, etc.).
    *   **Cuerpo (Body)**: Si se envían datos (con `POST`), van aquí. Por ejemplo, el usuario y contraseña de un login.

2.  **El Procesamiento**: El servidor recibe la petición. Un software llamado **Servidor Web** (como Apache o Nginx) la recoge. Si la petición es para un recurso estático (un `.jpg`, un `.css`), lo busca y lo devuelve. Si es para un recurso dinámico (un `.php`), se lo pasa a un intérprete especial para que ejecute el código. Este código puede hacer de todo: conectarse a una base de datos, llamar a otros servicios, etc.

3.  **La Respuesta (Response)**: Una vez procesada la petición, el servidor construye un mensaje de respuesta HTTP y se lo envía de vuelta al cliente. Este mensaje contiene:
    *   **Código de Estado**: Un número que resume el resultado. `200 OK` (todo bien), `404 Not Found` (no lo encuentro), `500 Internal Server Error` (la cocina está en llamas).
    *   **Cabeceras (Headers)**: Metadatos sobre la respuesta (el formato del contenido es `text/html`, la fecha, etc.).
    *   **Cuerpo (Body)**: ¡El contenido! Generalmente, el código HTML de la página que tu navegador mostrará.

Aquí tienes un diagrama de flujo de este proceso:

```mermaid
sequenceDiagram
    participant Cliente (Navegador)
    participant Servidor Web
    participant Intérprete PHP
    participant Base de Datos

    Cliente (Navegador)->>+Servidor Web: Petición GET /productos.php
    Servidor Web->>+Intérprete PHP: Ejecuta productos.php
    Intérprete PHP->>+Base de Datos: Consulta SQL: "SELECT * FROM productos"
    Base de Datos-->>-Intérprete PHP: Devuelve lista de productos
    Note right of Intérprete PHP: El script PHP genera el HTML<br>con los datos de los productos.
    Intérprete PHP-->>-Servidor Web: Devuelve el HTML generado
    Servidor Web-->>-Cliente (Navegador): Respuesta HTTP 200 OK + HTML
```

!!! question "¡A darle al coco!"
    1.  Cuando ves un vídeo en YouTube, ¿quién es el cliente y quién el servidor? ¿Qué tipo de petición HTTP crees que inicia la reproducción?
    2.  Busca qué significan los códigos de estado HTTP `403 Forbidden` y `301 Moved Permanently`. ¿En qué situación real te los podrías encontrar?
    3.  Si rellenas un formulario de contacto y le das a "Enviar", ¿qué método HTTP se está usando probablemente? ¿Dónde viajarían los datos que has escrito?

<br><br><hr/><br><br>

## La Anatomía de una Aplicación: Arquitectura en 3 Capas

Cuando las aplicaciones se complican, meter todo el código en un solo archivo es una receta para el desastre. Para organizar el trabajo, se usa la **arquitectura de 3 capas**, que separa la aplicación en tres áreas lógicas según su función.

!!! tip "Capas Lógicas vs. Capas Físicas"
    Es importante no confundir las capas lógicas (*layers*), que son una forma de organizar el código, con las capas físicas (*tiers*), que se refieren a máquinas o servidores físicos distintos. En un proyecto grande, cada capa lógica podría vivir en su propio servidor físico para mejorar la seguridad y el rendimiento.

Las tres capas lógicas son:

1.  **Capa de Presentación (Vista)**: Es todo lo que el usuario ve y con lo que interactúa. Su única misión es mostrar los datos de una forma bonita y recoger las acciones del usuario. En desarrollo web, esto es el HTML, CSS y JavaScript que se ejecuta en el navegador.

2.  **Capa de Lógica de Negocio (Controlador)**: Es el cerebro de la aplicación. Recibe las peticiones de la capa de presentación y decide qué hacer. Contiene las reglas del negocio: "si un usuario compra un producto, actualiza el stock, calcula el total con IVA y notifica al almacén". No sabe de colores ni de botones, solo de procesos. Esta capa vive en el servidor.

3.  **Capa de Acceso a Datos (Modelo)**: Es el guardián de la información. Su único trabajo es comunicarse con la base de datos (u otras fuentes de datos). Ofrece métodos sencillos a la capa de negocio para `getUser()`, `saveProduct()`, etc., sin que esta necesite saber el lenguaje "SQL" que se habla por debajo. También vive en el servidor.

Separar el código así es una idea brillante por varias razones:
*   **Mantenimiento**: Si quieres cambiar el diseño de un botón (Capa de Presentación), no tienes que tocar la lógica de cómo se calcula un precio (Capa de Negocio).
*   **Reutilización**: La misma lógica de negocio puede servir datos a una página web y a una aplicación móvil.
*   **Trabajo en Equipo**: El equipo de *front-end* puede trabajar en la presentación mientras el equipo de *back-end* se ocupa de la lógica y los datos.

```mermaid
graph TD
    A[<B>Usuario con Navegador</B>] -->|Petición HTTP| B["<b>Servidor Web / Aplicaciones</b><br><i>Lógica de Negocio</i>"]
    B -->|Consulta SQL| C["<b>Servidor de BBDD</b><br><i>Acceso a Datos</i>"]
    C -->|Datos| B
    B -->|Respuesta HTML| A

    subgraph "Capa de Presentación (Vista)"
    A
    end
    subgraph "Capa de Lógica (Controlador)"
    B
    end
    subgraph "Capa de Datos (Modelo)"
    C
    end

    style A fill:#D6EAF8
    style B fill:#D1F2EB
    style C fill:#FADBD8
```

!!! question "¡A darle al coco!"
    1.  En una app de banca online, la acción de "Hacer una transferencia" implica a las 3 capas. Describe qué tarea realizaría cada una en ese proceso.
    2.  Si la capa de datos está bien diseñada, ¿sería fácil cambiar de una base de datos MySQL a otra como PostgreSQL sin alterar la capa de negocio? ¿Por qué?
    3.  El lenguaje que usas en el front-end (JavaScript) es distinto al del back-end (PHP). ¿Qué capa actúa como "traductora" entre estos dos mundos?

<br><br><hr/><br><br>

## Montando tu Taller de Desarrollo: El Entorno de Servidor

Para empezar a programar en el lado del servidor, no puedes simplemente abrir un archivo `.php` en tu navegador como harías con un `.html`. Necesitas simular en tu propio ordenador todo el entorno que tendría un servidor real. A esto se le llama trabajar en un **entorno de desarrollo local**.

La "Santísima Trinidad" del desarrollo web con PHP, conocida como **stack LAMP** (Linux, Apache, MySQL, PHP), son las herramientas que necesitas instalar.

```markmap
# Entorno de Servidor (Stack)

## La Santísima Trinidad
- **Servidor Web**: Apache / Nginx
  - Es el "camarero". Recibe las peticiones HTTP y decide qué hacer con ellas.
- **Intérprete de Lenguaje**: PHP
  - Es el "chef". Ejecuta tu código `.php` y genera el HTML.
- **Base de Datos**: MySQL / MariaDB
  - Es la "despensa". Almacena y gestiona todos tus datos de forma persistente.

## ¿Cómo lo instalo?
- **Paquetes "Todo en uno" (XAMPP)**
  - **Pros**: ¡Facilísimo! Un solo instalador para todo. Ideal para empezar.
  - **Contras**: Menos flexible. Las versiones de los programas son las que son.
- **Contenedores (Docker)**
  - **Pros**: El estándar profesional. Replica el entorno de producción 1:1. Cada proyecto tiene sus contenedores aislados.
  - **Contras**: Requiere un aprendizaje inicial. Es más complejo de configurar la primera vez.
```

Para este curso, podéis usar la herramienta que prefiráis, aunque os animo a que os peleéis con **Docker**. Es lo que os vais a encontrar en el 90% de las empresas hoy en día, y aprenderlo ahora os dará una ventaja competitiva brutal.

### ¡Nuestro Primer "Hola Mundo" en PHP!

Una vez tengas tu entorno local funcionando (ya sea con XAMPP o Docker), vamos a crear nuestra primera página dinámica. Crea un archivo llamado `index.php` en la carpeta raíz de tu servidor web (normalmente `htdocs` en XAMPP o la carpeta que hayas configurado en Docker).

```html+php
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¡Mi primera página PHP!</title>
</head>
<body>
    <h1>¡Esto es HTML estático!</h1>
    <p>La fecha y hora actuales en el servidor son:</p>
    <p>
        <strong>
            <?php
                // Código PHP embebido en HTML
                // La función date() formatea la fecha y hora del servidor.
                echo date('d/m/Y H:i:s');
            ?>
        </strong>
    </p>

</body>
</html>
```
!!! tip "PSR-12 al poder"
    Fíjate en el estilo del código PHP: la llave de apertura en la misma línea, indentación de 4 espacios... Son las reglas de **PSR-12**, un estándar de estilo que hace el código más legible y profesional. Acostúmbrate a seguirlo desde el primer día.

Ahora, abre tu navegador y visita `http://localhost`. Verás la página, ¡y la hora cambiará cada vez que la recargues! Acabas de crear tu primera página dinámica.

!!! question "¡A darle al coco!"
    1. Crea un nuevo fichero `info.php`. Dentro, escribe solo el siguiente código: `<?php phpinfo(); ?>`. Cárgalo en el navegador. Esta función es una "radiografía" completa de tu instalación de PHP. Investiga y anota qué valores tienen las directivas `memory_limit` y `upload_max_filesize`. ¿Para qué sirven?
    2. Modifica el `index.php` para que, además de la fecha, muestre un número aleatorio entre 1 y 100. (Pista: busca la función `rand()` de PHP).
    3. Si movieras tu `index.php` a una subcarpeta llamada `proyecto1`, ¿qué URL tendrías que escribir en el navegador para verlo?

<br><br><hr/><br><br>

## Aplicación en el Mundo Real

No es una exageración: **toda la web interactiva funciona con estos principios**.

*   **Redes Sociales (Facebook, X, Instagram)**: Cuando ves tu *feed*, un script en el servidor está consultando la base de datos para obtener las últimas publicaciones de la gente a la que sigues, tus notificaciones y los anuncios personalizados para ti. Todo eso se ensambla en una página dinámica y se te envía. No hay dos *feeds* iguales.
*   **E-commerce (Amazon, Zara, PcComponentes)**: Al buscar un producto, estás enviando una petición `GET` con tu búsqueda. El servidor ejecuta una lógica de negocio compleja para encontrar resultados, comprobar el stock, buscar productos relacionados y mostrarte precios, todo consultando una gigantesca base de datos. Cuando compras, envías un `POST` con tus datos, y se desencadena otro proceso en el servidor.
*   **Cualquier servicio con un login (Gmail, Netflix, tu banco)**: El simple hecho de iniciar sesión es un ciclo cliente-servidor puro. Envías tus credenciales, el servidor las valida contra la capa de datos y, si son correctas, te genera una página de bienvenida personalizada.

Entender estas arquitecturas no solo te prepara para ser programador, sino para comprender cómo funciona el mundo digital en el que vivimos.

## Para Saber Más

La curiosidad es el motor del buen desarrollador. Si te has quedado con ganas de más, aquí tienes algunos recursos de altísima calidad para profundizar:

1.  **MDN Web Docs: An overview of HTTP**: La mejor referencia, clara y concisa, sobre el protocolo que lo sustenta todo. [https://developer.mozilla.org/es/docs/Web/HTTP/Overview](https://developer.mozilla.org/es/docs/Web/HTTP/Overview)
2.  **PHP: The Right Way**: Una guía popular y muy recomendable que recopila las mejores prácticas, estándares de código y enlaces a las herramientas más populares en el ecosistema PHP moderno. Imprescindible. [https://phptherightway.com/](https://phptherightway.com/)
3.  **Docker 101 Tutorial**: El tutorial oficial de Docker para empezar a dar tus primeros pasos con la tecnología de contenedores que domina la industria. [https://www.docker.com/101-tutorial/](https://www.docker.com/101-tutorial/)