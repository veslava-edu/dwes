<!-- Nombre de archivo sugerido: T01_Arquitectura-Web-y-Software-en-Servidor.md -->
# Arquitecturas Web: De los Cimientos a la Nube

¡Muy buenas, futuros cracks del desarrollo! Hoy vamos a sentar las bases de todo lo que construiremos en este curso. Hablaremos de **arquitectura web**. Pensad en ello como si fuerais arquitectos de edificios. No es lo mismo diseñar una caseta de jardín que un rascacielos de 80 plantas. La caseta es rápida de hacer, pero no le pidas que aguante un huracán o que aloje a 5.000 personas. El rascacielos, en cambio, requiere una planificación brutal, unos cimientos sólidos y una estructura a prueba de bombas, pero a cambio te ofrece una escalabilidad y una robustez impresionantes.

En el mundo web, la arquitectura son los planos de nuestra aplicación. Define cómo se organizan las piezas, cómo se comunican entre sí y, lo más importante, cómo podremos hacerla crecer en el futuro sin que todo el chiringuito se nos venga abajo. Entender estos conceptos es la diferencia entre construir "chapuzas" digitales y crear aplicaciones profesionales y mantenibles. ¡Vamos a por los planos!

Los modelos de **arquitectura web** describen la relación entre los distintos elementos que componen la estructura de funcionamiento de las páginas y aplicaciones web. A continuación se describen los principales modelos de arquitectura utilizados en el despliegue de aplicaciones web, cada uno con sus propias características, ventajas y desventajas.

## 1. Modelo Punto a Punto (P2P - Peer to Peer)

Es una arquitectura de red descentralizada donde cada nodo (o "par") actúa simultáneamente como cliente y como servidor. A diferencia del modelo cliente-servidor, no depende de un servidor central para coordinar las tareas o distribuir los recursos.

En una red P2P, las cargas de trabajo, como el streaming de contenido, se distribuyen entre todos los participantes, quienes aportan sus propios recursos (CPU, ancho de banda, almacenamiento) a la red.

### Ventajas
- **Escalabilidad:** Funciona mejor cuantos más nodos se conectan, al contrario que el modelo cliente-servidor.
- **Robustez:** La caída de un nodo no afecta al funcionamiento general de la red, ya que no hay un punto central de fallo.
- **Descentralización:** Ningún nodo es indispensable para el funcionamiento de la red.
- **Distribución de costes:** La carga y los costes se reparten entre todos los participantes.

### Desventajas
- **Fiabilidad de recursos:** No hay garantía de que los recursos obtenidos sean los deseados o no hayan sido alterados.
- **Mantenimiento complejo:** La actualización de los recursos debe realizarse en todos los nodos de la red.

![Red P2P](images/P2P.png)

## 2. Modelo Cliente-Servidor

Es el modelo más tradicional, donde las tareas se reparten entre proveedores de servicios (**servidores**) y solicitantes de servicios (**clientes**). La comunicación se realiza a través de una red, donde los clientes envían peticiones y los servidores envían respuestas.

En una arquitectura web simple, el servidor web envía los recursos (HTML, imágenes, etc.) tal como están almacenados, sin realizar ningún procesamiento sobre ellos.

### Ventajas
- **Control centralizado:** La seguridad, los accesos y la integridad de los datos se gestionan desde el servidor.
- **Mantenimiento sencillo:** Es fácil actualizar, reparar o reemplazar un servidor sin afectar a los clientes.
- **Escalabilidad:** Se puede aumentar la capacidad de clientes y servidores de forma independiente.

### Desventajas
- **Congestión de tráfico:** Un alto número de peticiones simultáneas puede sobrecargar y tumbar el servidor.
- **Punto único de fallo:** Si el servidor se cae, el servicio deja de estar disponible para todos los clientes.
- **Coste:** El hardware y software específico para un servidor suele tener un coste elevado.

![Cliente-Servidor](images/Modelo_cliente-servidor.png)

## 3. Modelos con Servidor de Aplicaciones

Esta arquitectura introduce un **servidor de aplicaciones**, cuya función es ejecutar código y procesar lógica de negocio antes de devolver un resultado. A diferencia de un servidor web que solo entrega archivos estáticos, este modelo genera contenido dinámico.

### 3.1. Servidor de Aplicaciones en la misma máquina

En este esquema, el servidor web y el servidor de aplicaciones residen en la misma máquina. El servidor web recibe la petición; si es para un recurso estático, lo devuelve directamente, pero si es para un recurso dinámico, pasa la petición al servidor de aplicaciones para que la procese. El servidor de aplicaciones a menudo se conecta a una base de datos.

![Servidor de Aplicaciones en la misma máquina](images/Modelo_servidor_aplicaciones_1.png)



### 3.2. Servidor de Aplicaciones Externo

Para optimizar recursos, el servidor web y el de aplicaciones se instalan en máquinas separadas. El servidor web, que requiere menos carga, gestiona todo el tráfico y utiliza un **redirector** para enviar solo las peticiones dinámicas al servidor de aplicaciones. Los recursos estáticos se sirven directamente desde el servidor web.

![Servidor de Aplicaciones Externo](images/Modelo_servidor_aplicaciones_externo.png)


### 3.3. Múltiples Servidores de Aplicaciones con Balanceador de Carga

Cuando la carga de trabajo es muy elevada, se utiliza un único servidor web que se comunica con **varios servidores de aplicaciones idénticos (clones)**. El redirector en este caso actúa también como un **balanceador de carga**, distribuyendo las peticiones entre los diferentes servidores de aplicaciones para evitar la sobrecarga de uno solo y garantizar la alta disponibilidad.

![Múltiples Servidores de Aplicaciones con Balanceador de Carga](images/Modelo_servidor_aplicaciones_varios.png)


## 3. Modelos Cliente-Servidor

![Cliente-Servidor](images/clienteservidor.png)


## Conceptos Fundamentales

Antes de ponernos a tirar líneas de código, es vital que todos hablemos el mismo idioma. Aquí tenéis los términos clave de nuestro día a día.

!!! note "Cliente"
    Es el que empieza la conversación. En el 99% de los casos, será el **navegador web** (Chrome, Firefox, Safari...) que usa una persona en su ordenador o móvil. Es el que tiene la necesidad y pide información.
    *Analogía*: El cliente es como un comensal en un restaurante que hace un pedido al camarero.

!!! note "Servidor"
    Es la máquina (y el software) que está a la escucha, esperando peticiones del cliente para darles una respuesta. Por lo general, es un ordenador potente que está encendido 24/7. Si la web fuera un restaurante, el cliente es el comensal y el servidor es toda la cocina y los camareros.
	
!!! note "Arquitectura Cliente-Servidor"
    Es el modelo de comunicación fundamental en la web. El cliente realiza una **petición** (*request*) a través de la red, y el servidor le devuelve una **respuesta** (*response*). Este diálogo constante es la base de casi todo lo que pasa en Internet.

!!! note "Página Web Estática"
    Imagina que pides una pizza precocinada. El servidor la tiene ya hecha en su "disco duro", y te la envía tal cual. Es un simple archivo (HTML, CSS, JS) que no cambia, sin importar quién o cuándo lo pida. Son rápidas y sencillas, ideales para páginas informativas, portfolios o blogs básicos.

!!! note "Página Web Dinámica"
    Aquí la cosa se pone interesante. Pides una pizza, y el chef (el servidor) la cocina en ese mismo momento con los ingredientes que tú has elegido. El servidor ejecuta un programa (por ejemplo, en PHP) que genera el HTML sobre la marcha, a menudo consultando una base de datos para obtener información personalizada. Tu perfil de Instagram es un ejemplo perfecto: la página se construye dinámicamente con tus fotos, tus seguidores y tus mensajes.

## Desarrollo y Ejemplos Prácticos

### El Diálogo: Páginas Estáticas vs. Dinámicas

Imagina que un usuario abre su navegador y teclea una dirección. ¿Qué pasa por detrás? Se inicia un diálogo usando el protocolo **HTTP** (Hypertext Transfer Protocol), el idioma universal de la web.

*   **En una web estática**, el diálogo es corto:
    1.  Cliente: "¡Oye, servidor! ¿Me das la página `quienes-somos.html`?"
    2.  Servidor: "¡Claro! Aquí la tienes." (Le envía el fichero HTML que ya tenía preparado).

*   **En una web dinámica**, la cosa se anima:
    1.  Cliente: "¡Servidor! Dame la página `mi-perfil.php`."
    2.  Servidor: "¡Recibido! Un momento, que esto hay que cocinarlo."
    3.  El servidor web (como Apache) ve que el fichero es `.php` y, en lugar de enviarlo directamente, se lo pasa al **intérprete de PHP**.
    4.  El script de PHP se ejecuta. Puede que haga cosas como: "Voy a la base de datos a buscar el nombre y los últimos pedidos de este usuario".
    5.  Una vez tiene los datos, PHP genera un documento HTML único para ese usuario y se lo devuelve al servidor.
    6.  Servidor: "¡Listo! Aquí tienes tu página recién hecha." (Envía el HTML resultante al cliente).


### El Duelo: ¿Estático o Dinámico?

La diferencia fundamental entre una página estática y una dinámica reside en **dónde se genera el contenido**.

*   **Páginas estáticas:** El servidor actúa como un simple almacén. Recibe una petición de un fichero, lo busca en su disco duro y lo envía. No piensa, solo sirve.
*   **Páginas dinámicas:** El servidor se convierte en una fábrica. Recibe una petición, pero en lugar de buscar un fichero HTML, ejecuta un programa. Este programa (nuestro *script* de PHP, por ejemplo) puede hacer de todo: consultar una base de datos, conectarse a otros servicios, realizar cálculos... y con toda esa información, **construye una página HTML a medida** que finalmente envía al cliente.

El navegador del usuario final **nunca ve el código PHP**. Solo recibe el resultado final: un HTML limpio y listo para ser renderizado.

```html+php
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¡Hola, Mundo Dinámico!</title>
</head>
<body>
    <h1>Ejemplo Básico en PHP</h1>
    
    <!-- Este código se ejecuta en el servidor -->
    <?php
        echo "<p>Este párrafo ha sido generado por PHP.</p>";
        echo "<p>La fecha y hora actual del servidor es: " . date('Y-m-d H:i:s') . "</p>";
    ?>
    
    <p>Este párrafo es HTML estático de toda la vida.</p>
</body>
</html>
```

![Página dinámica VS Página estática](images/paginadinamica.png)


### La Arquitectura de 3 Capas: Organizando el Caos

Cuando una aplicación empieza a crecer, tenerlo todo mezclado en un mismo sitio es una receta para el desastre. Es como intentar gestionar un restaurante donde el chef también toma nota de los pedidos y friega los platos. La solución profesional es separar las responsabilidades. Aquí es donde brilla la **arquitectura de 3 capas**.

Hay que distinguir entre capas **lógicas** (*layers*), que se refieren a cómo organizamos nuestro código, y capas **físicas** (*tiers*), que se refieren a dónde se ejecuta ese código (en qué máquinas). La arquitectura de 3 capas lógicas es un estándar en la industria:

1.  **Capa de Presentación (Frontend):** Es la cara visible de nuestra aplicación, la interfaz de usuario. Todo lo que el usuario ve y toca en su navegador (HTML, CSS, JavaScript). Su única misión es mostrar la información de forma atractiva y capturar las acciones del usuario.
2.  **Capa de Negocio o Lógica (Backend):** Es el cerebro. Aquí vive la lógica de la aplicación, las reglas del juego. Este código, que escribiremos en PHP, procesa las peticiones de la capa de presentación, decide qué hacer y se comunica con la capa de datos.
3.  **Capa de Datos o Persistencia (Backend):** Es la memoria a largo plazo. Se encarga de almacenar y recuperar la información, normalmente interactuando con un sistema gestor de bases de datos (BBDD) como MySQL o MariaDB.

!!! tip
    En un proyecto pequeño, estas tres capas lógicas pueden coexistir en una única capa física (un solo servidor). En gigantes como Amazon, cada capa lógica está distribuida en miles de servidores físicos diferentes, con balanceadores de carga y clusters para garantizar el rendimiento.


```mermaid
graph TD
    A[Usuario con Navegador Web] -->|Petición HTTP| B["Servidor Web / Aplicaciones (Capa de Negocio)"]
    B -->|Consulta SQL| C["Servidor de BBDD (Capa de Datos)"]
    C -->|Datos| B
    B -->|Respuesta HTML| A

    subgraph Capa de Presentación
        A
    end
    subgraph Capa de Lógica
        B
    end
    subgraph Capa de Datos
        C
    end
```

### El Patrón MVC: El Chef, el Camarero y la Despensa

Dentro de la capa de negocio, podemos (¡y debemos!) ser aún más organizados. El patrón de diseño **Modelo-Vista-Controlador (MVC)** es una filosofía de trabajo que nos ayuda a estructurar el código del backend. Es tan popular que la mayoría de los *frameworks* modernos de PHP (como Laravel o Symfony) se basan en él.

*   **Modelo:** Representa los datos. Es el único que sabe hablar con la base de datos. Si necesitas obtener una lista de usuarios o guardar un nuevo producto, se lo pides al Modelo. Su lema es: "Yo me encargo de los datos, no me preguntes cómo se van a ver".
*   **Vista:** Representa la interfaz de usuario. Es una plantilla (normalmente un fichero HTML con huecos) que se rellena con los datos. Es "tonta": no tiene lógica, solo se dedica a presentar la información que le dan.
*   **Controlador:** Es el director de orquesta. Recibe la petición del usuario, habla con el Modelo para obtener los datos necesarios, y finalmente, elige una Vista y le pasa esos datos para que los muestre. Es el intermediario que coordina todo.

!!! warning
    Un error de novato clásico es poner código para acceder a la base de datos dentro de la Vista. ¡Jamás! Eso crea un "código espagueti" que es imposible de mantener. Cada componente tiene su responsabilidad. Si lo respetas, tu "yo" del futuro te lo agradecerá.

## Aplicación en el Mundo Real

Esta forma de estructurar las aplicaciones no es un capricho académico, es el estándar de la industria.

*   **Cualquier red social (Facebook, X, TikTok):** Cuando ves tu *feed*, un **Controlador** ha recibido la petición, ha pedido al **Modelo** tus publicaciones y las de tus amigos de la base de datos, y se las ha pasado a una **Vista** para que te las muestre en un scroll infinito.
*   **Un e-commerce (Amazon, PcComponentes):** El catálogo de productos vive en la capa de datos. La lógica para añadir un producto al carrito, calcular el total o procesar un pago reside en la capa de negocio. Y lo que tú ves en tu navegador es la capa de presentación.
*   **Herramientas de trabajo (Trello, Google Docs):** Son aplicaciones web increíblemente complejas que siguen estos mismos principios para separar la lógica de negocio de la presentación y los datos, permitiendo que equipos enormes de desarrolladores trabajen en paralelo sin pisarse los unos a los otros.
*   **WordPress**, el CMS que potencia una parte enorme de la web, es una gigantesca aplicación PHP construida sobre una arquitectura de 3 capas. Tiene su capa de presentación (los temas), su capa de negocio (el core de WordPress y los plugins) y su capa de datos (la base de datos MySQL).

Comprender estas arquitecturas es fundamental para tu futuro laboral. Cuando una oferta de trabajo pida un "desarrollador Backend", sabrás que buscan a alguien para trabajar en las capas de negocio y datos. Si piden un "desarrollador Frontend", se centrarán en la capa de presentación. Y un "Full-Stack"... bueno, ese es el valiente que se atreve con todo el restaurante, desde la cocina hasta la decoración de las mesas.

## Para Saber Más

La curiosidad es el motor de un buen desarrollador. Aquí tienes algunos recursos de alta calidad para profundizar en estos conceptos:

1.  **MDN Web Docs - Introducción al funcionamiento de la Web:** Una explicación detallada y clara de los conceptos básicos de cliente, servidor y el protocolo HTTP. Imprescindible. [https://developer.mozilla.org/es/docs/Learn/Getting_started_with_the_web/How_the_Web_works](https://developer.mozilla.org/es/docs/Learn/Getting_started_with_the_web/How_the_Web_works)
2.  **freeCodeCamp - El patrón Modelo-Vista-Controlador:** Un artículo muy completo que explica el patrón MVC con ejemplos claros, ideal para asentar las bases. [https://www.freecodecamp.org/espanol/news/el-patron-modelo-vista-controlador-arquitectura-y-frameworks-explicados/](https://www.freecodecamp.org/espanol/news/el-patron-modelo-vista-controlador-arquitectura-y-frameworks-explicados/)
3.  **Vídeo "La legendaria arquitectura de 3 capas" por Manuel Zapata:** Una explicación visual y amena que te ayudará a solidificar la diferencia entre capas y su propósito. [https://www.youtube.com/watch?v=A3sP6vuT5P0](https://www.youtube.com/watch?v=A3sP6vuT5P0)
4.  **Arquitectura WEB avanzada:** [Modelo completo](https://medium.com/@maniakhitoccori/arquitectura-web-39fe6635f6b4)

---


# Proyecto "Nexus Intranet": Ejercicios de Arquitectura Web

¡Hola, equipo! Bienvenidos a Innovatech Solutions. Como nuestro nuevo equipo de desarrollo, vuestra primera misión es clave para el futuro de la comunicación interna de la empresa: **construir los cimientos de "Nexus", nuestra nueva intranet corporativa**. Este portal será el corazón digital de Innovatech, un lugar para noticias, un directorio de empleados, gestión de eventos y mucho más.

En esta primera fase, nos centraremos en aplicar los conceptos fundamentales de la arquitectura web. No construiremos la aplicación completa, sino que desarrollaremos prototipos y módulos clave para asegurarnos de que la base (la arquitectura) es sólida, profesional y escalable. Cada ejercicio es un paso para construir un componente de "Nexus". ¡Manos a la obra!

## Ejercicios de Consolidación

Aquí sentaremos las bases. Estos ejercicios están diseñados para asegurar que todos compartimos un mismo entendimiento de los conceptos clave antes de construir componentes más complejos.

!!! abstract "Diagnóstico de Arquitectura: El Glosario de Innovatech | Nivel: Fácil"
    
    **Objetivo:** Validar la comprensión de los términos fundamentales de la arquitectura web (Cliente, Servidor, Estático vs. Dinámico, Arquitectura Cliente-Servidor).

    **Tarea a Realizar:** Responde a las siguientes preguntas basándote en el material didáctico y tu propia investigación. Sé conciso y claro, como si se lo explicaras a un nuevo becario del departamento de marketing.

    1.  Si un empleado usa Chrome en su portátil para acceder a Nexus, ¿qué rol juega Chrome en la arquitectura cliente-servidor?
    2.  Cuando Nexus muestre una página con las ofertas de menú del día de la cafetería, que cambian cada día, ¿será una página estática o dinámica? Justifica tu respuesta.
    3.  Describe con tus propias palabras el flujo de una petición HTTP cuando un usuario solicita ver su perfil personalizado en la intranet Nexus. ¿Quién "cocina" la respuesta?
    4.  ¿Por qué el navegador de un usuario nunca ve el código PHP de una página dinámica?
    5.  En la arquitectura de 3 capas de Nexus, ¿qué capa sería la responsable de conectarse a la base de datos para obtener la lista de empleados?

    **Aplicación en el Mundo Real:** Este conocimiento es la base de cualquier conversación técnica en un equipo de desarrollo. Usar los términos correctamente evita malentendidos y demuestra profesionalidad al discutir cómo implementar nuevas funcionalidades.
	
    ??? success "VER Solución."

        **1. Rol de Chrome:**
        Chrome actúa como el **Cliente**. Es el software que inicia la petición para obtener la página web de la intranet.

        **2. Menú del día:**
        Sería una **página dinámica**. Aunque el contenido no es personalizado por usuario, cambia con el tiempo (diariamente). El servidor necesita ejecutar un script (ej. en PHP) para leer el menú de hoy (desde una base de datos o un fichero) y generar el HTML correspondiente. Una página estática sería la misma para todos, siempre.

        **3. Flujo de perfil personalizado:**
        El flujo de una petición HTTP cuando un usuario solicita ver su perfil personalizado sería el siguiente:
        *   El **Cliente** (navegador) envía una petición HTTP (ej: `GET /perfil.php`).
        *   El **Servidor Web** recibe la petición. Ve que es un fichero `.php` y se lo pasa al intérprete de PHP.
        *   El script PHP (la **Capa de Negocio**) se ejecuta. Probablemente, se conecte a la **Capa de Datos** (base de datos) para buscar la información del usuario que ha iniciado sesión.
        *   Con los datos obtenidos, PHP "construye" un documento HTML a medida.
        *   El Servidor Web envía ese HTML generado como respuesta al Cliente.
        *   El Cliente (navegador) renderiza el HTML para que el usuario lo vea.

        El que "cocina" la respuesta es el **servidor**, específicamente el software del lado del servidor (el intérprete de PHP en este caso).

        **4. Código PHP invisible:**
        El navegador nunca ve el código PHP porque este se ejecuta **exclusivamente en el servidor**. El servidor procesa el script y lo único que envía de vuelta al cliente es el **resultado** de esa ejecución, que es un texto plano en formato HTML.

        **5. Capa responsable de los datos:**
        La **Capa de Datos** (o de Persistencia) es la única responsable de interactuar con la base de datos.


!!! success "Ejercicio de Consolidación | Dificultad: Baja"
    #### 2. La Página de Aterrizaje Estática de Nexus
    **Objetivo:** Crear una página web estática simple, aplicando los conceptos de HTML y la función del servidor como mero distribuidor de ficheros.
    **Setup Inicial:** Crea una carpeta en tu ordenador llamada `nexus-project`. Dentro, crea un fichero llamado `index.html`.
    **Tarea a Realizar:**
    1.  Edita el fichero `index.html`.
    2.  Dentro, crea la estructura básica de un documento HTML5.
    3.  El título de la página (`<title>`) debe ser "Bienvenido a Nexus Intranet".
    4.  En el `<body>`, añade un encabezado `<h1>` que diga "Nexus: Conectando Innovatech Solutions".
    5.  Añade un párrafo `<p>` con una breve descripción de la intranet: "El portal interno para todos los empleados de Innovatech. Encuentra noticias, directorios y herramientas aquí."
    6.  Abre el fichero `index.html` directamente en tu navegador para ver el resultado.
    **Aplicación en el Mundo Real:** Muchas páginas web o partes de una aplicación no necesitan lógica de servidor. Páginas como "Términos y Condiciones", "Política de Privacidad" o páginas de aterrizaje de marketing a menudo son estáticas por su rapidez de carga y simplicidad.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    ```html
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenido a Nexus Intranet</title>
    </head>
    <body>
        <h1>Nexus: Conectando Innovatech Solutions</h1>
        <p>El portal interno para todos los empleados de Innovatech. Encuentra noticias, directorios y herramientas aquí.</p>
    </body>
    </html>
    ```
    </details>

!!! success "Ejercicio de Consolidación | Dificultad: Baja"
    #### 3. Dinamizando el Saludo de Bienvenida
    **Objetivo:** Convertir una parte de una página estática en contenido dinámico usando PHP para mostrar información generada por el servidor.
    **Setup Inicial:**
    1.  Necesitarás un entorno de desarrollo local con PHP y un servidor web (como XAMPP, WAMP, MAMP o el servidor integrado de PHP).
    2.  Dentro de tu carpeta `nexus-project`, renombra el fichero `index.html` a `index.php`.
    3.  Asegúrate de que puedes servir este fichero desde tu servidor local y verlo en el navegador (ej: `http://localhost/nexus-project/`).
    **Tarea a Realizar:**
    1.  Abre el fichero `index.php`.
    2.  Debajo del párrafo existente, añade un nuevo párrafo.
    3.  En lugar de texto estático, dentro de este párrafo vas a insertar un bloque de código PHP que imprima la fecha y hora actual del servidor. Utiliza la función `date()` de PHP que se muestra en el material de referencia.
    4.  El resultado final en el navegador debería mostrar el texto estático de antes, y debajo, un mensaje como: "Hora del servidor: 2025-07-25 16:30:00".
    **Aplicación en el Mundo Real:** Esta es la forma más básica de contenido dinámico. Se usa en todas partes: para mostrar la hora, desear "buenos días" o "buenas tardes" según el momento del día, o para personalizar un saludo con el nombre del usuario que ha iniciado sesión.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    ```html+php
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenido a Nexus Intranet</title>
    </head>
    <body>
        <h1>Nexus: Conectando Innovatech Solutions</h1>
        <p>El portal interno para todos los empleados de Innovatech. Encuentra noticias, directorios y herramientas aquí.</p>
        
        <!-- Contenido dinámico añadido -->
        <p>
            <?php
                echo "Hora del servidor: " . date('Y-m-d H:i:s');
            ?>
        </p>
    </body>
    </html>
    ```
    </details>

!!! success "Ejercicio de Consolidación | Dificultad: Baja"
    #### 4. Investigación: El Protocolo HTTP, el Lenguaje de la Web
    **Objetivo:** Investigar y comprender los componentes más comunes del protocolo HTTP que sustentan la comunicación cliente-servidor.
    **Tarea a Realizar:**
    1.  **Investigación:** Utilizando la web de MDN Web Docs o fuentes fiables, investiga los siguientes conceptos de HTTP:
        *   Método `GET` vs. Método `POST`: ¿Cuál es su propósito principal y en qué se diferencian? ¿Cuándo usarías uno sobre el otro?
        *   Códigos de Estado: ¿Qué significan los siguientes códigos de estado y cuándo los encontrarías?
            *   `200 OK`
            *   `404 Not Found`
            *   `500 Internal Server Error`
            *   `301 Moved Permanently`
    2.  **Exposición:** Prepara una breve exposición oral (3-5 minutos) para presentar tus hallazgos a tus compañeros. Debes ser capaz de explicar cada punto con un ejemplo práctico relacionado con la intranet Nexus.
    **Aplicación en el Mundo Real:** Como desarrollador, te enfrentarás a códigos de estado HTTP todos los días al depurar aplicaciones o al interactuar con APIs. Entender los métodos HTTP es crucial para diseñar formularios y servicios web que funcionen de manera segura y predecible.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    **Puntos Clave para la Investigación y Exposición:**

    *   **Método `GET`:**
        *   **Propósito:** Solicitar datos de un recurso específico. Es el método que usa el navegador por defecto cuando escribes una URL.
        *   **Características:** Los datos se envían en la URL (query string). Tiene un límite de longitud. Es cacheable. No debe usarse para enviar datos sensibles.
        *   **Ejemplo Nexus:** Solicitar la página de noticias (`GET /noticias.php`).
    *   **Método `POST`:**
        *   **Propósito:** Enviar datos a un servidor para crear o actualizar un recurso.
        *   **Características:** Los datos se envían en el cuerpo (body) de la petición HTTP. No tiene límite de tamaño. No se cachea. Es el método adecuado para formularios con datos sensibles (como un login) o para subir ficheros.
        *   **Ejemplo Nexus:** Enviar los datos del formulario de "Añadir Nuevo Evento".
    *   **Código `200 OK`:**
        *   **Significado:** La petición ha tenido éxito. Es la respuesta estándar para peticiones correctas.
        *   **Ejemplo Nexus:** El servidor lo devuelve cuando entrega correctamente la página `index.php`.
    *   **Código `404 Not Found`:**
        *   **Significado:** El servidor no pudo encontrar el recurso solicitado. El cliente ha pedido una URL que no existe.
        *   **Ejemplo Nexus:** El usuario escribe mal la URL `http://localhost/nexus-project/noticais.php` (error tipográfico).
    *   **Código `500 Internal Server Error`:**
        *   **Significado:** Ha ocurrido un error inesperado en el servidor que le ha impedido completar la petición. Es un error del lado del servidor.
        *   **Ejemplo Nexus:** El script `perfil.php` intenta conectar a la base de datos, pero la contraseña es incorrecta y el código no maneja el error, provocando que el script "rompa".
    *   **Código `301 Moved Permanently`:**
        *   **Significado:** El recurso solicitado ha sido movido permanentemente a una nueva URL.
        *   **Ejemplo Nexus:** La antigua página de contacto (`/contacto.html`) ahora redirige permanentemente a la nueva página (`/soporte/contacto/`).
    </details>

!!! success "Ejercicio de Consolidación | Dificultad: Media"
    #### 5. ¡Bug a la Vista! El Directorio de Empleados no Carga
    **Objetivo:** Desarrollar habilidades de depuración identificando y corrigiendo un error común en un script PHP que mezcla responsabilidades (lógica de datos en la presentación).
    **Setup Inicial:**
    1.  Crea un nuevo fichero en tu proyecto llamado `directorio_bug.php`.
    2.  Copia y pega el siguiente código en el fichero. Este código intenta simular la obtención de datos de empleados y mostrarlos.
    ```php
    <?php
        // --- SIMULACIÓN DE CAPA DE DATOS ---
        // En un caso real, esto vendría de una BBDD.
        // ¡ERROR INTENCIONADO! La función se llama `obtener_empleades`, pero abajo se llama de otra forma.
        function obtener_empleades() {
            return [
                ["nombre" => "Ana García", "puesto" => "Desarrolladora Backend"],
                ["nombre" => "Carlos Pérez", "puesto" => "Diseñador UX/UI"],
            ];
        }
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Directorio de Empleados - Nexus</title>
    </head>
    <body>
        <h1>Directorio de Empleados</h1>
        <ul>
            <?php
                // --- LÓGICA DE NEGOCIO Y PRESENTACIÓN MEZCLADAS ---
                // Se intenta obtener los empleados llamando a una función con el nombre incorrecto.
                $lista_empleados = obtener_empleados(); // <-- ¡AQUÍ ESTÁ EL BUG!
                
                // Se intenta acceder a la variable aunque la llamada anterior falló.
                foreach ($lista_empleados as $empleado) {
                    echo "<li>" . $empleado['nombre'] . " - " . $empleado['puesto'] . "</li>";
                }
            ?>
        </ul>
        <!-- Este código está mal ubicado. La lógica de datos debería estar separada. -->
    </body>
    </html>
    ```
    **Tarea a Realizar:**
    1.  Ejecuta el script `directorio_bug.php` en tu servidor. Observarás que no funciona y probablemente veas un error de PHP (o una página en blanco, dependiendo de tu configuración).
    2.  Lee el mensaje de error que te muestra PHP. Intenta comprender qué significa.
    3.  Revisa el código y encuentra la causa del error. Hay un error tipográfico.
    4.  Corrige el error para que la lista de empleados se muestre correctamente.
    5.  **Reflexión:** ¿Qué principio de la arquitectura de 3 capas o MVC se está violando en este fichero?
    **Aplicación en el Mundo Real:** La depuración es el 90% del trabajo de un desarrollador. Aprender a leer mensajes de error, rastrear el flujo del código y encontrar bugs es una habilidad fundamental. Este tipo de error, una simple errata, es extremadamente común.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    1.  **El Bug:** La función se define como `obtener_empleades()` pero luego es llamada como `obtener_empleados()`. PHP lanza un error fatal porque no encuentra la función `obtener_empleados()`.

    2.  **Código Corregido:**
    ```php
    <?php
        // --- SIMULACIÓN DE CAPA DE DATOS ---
        function obtener_empleades() {
            return [
                ["nombre" => "Ana García", "puesto" => "Desarrolladora Backend"],
                ["nombre" => "Carlos Pérez", "puesto" => "Diseñador UX/UI"],
            ];
        }
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Directorio de Empleados - Nexus</title>
    </head>
    <body>
        <h1>Directorio de Empleados</h1>
        <ul>
            <?php
                // --- LÓGICA DE NEGOCIO Y PRESENTACIÓN MEZCLADAS ---
                // Se corrige la llamada a la función
                $lista_empleados = obtener_empleades(); // <-- CORREGIDO
                
                foreach ($lista_empleados as $empleado) {
                    echo "<li>" . $empleado['nombre'] . " - " . $empleado['puesto'] . "</li>";
                }
            ?>
        </ul>
    </body>
    </html>
    ```

    3.  **Reflexión sobre Arquitectura:** Este fichero viola el principio de **Separación de Responsabilidades**.
        *   El código PHP que define la función `obtener_empleades()` actúa como **Capa de Datos/Modelo**.
        *   El código PHP que llama a la función y procesa el bucle actúa como **Capa de Negocio/Controlador**.
        *   El HTML que estructura la página y el `echo` dentro del bucle actúan como **Capa de Presentación/Vista**.
        
        Tener las tres responsabilidades mezcladas en un solo fichero es un ejemplo de "código espagueti", lo que dificulta su mantenimiento y escalabilidad, tal como advierte el material didáctico.
    </details>

!!! success "Ejercicio de Consolidación | Dificultad: Media"
    #### 6. Análisis de Caso: La Arquitectura de una Red Social
    **Objetivo:** Aplicar los conceptos de la arquitectura de 3 capas y MVC al análisis de una aplicación real y compleja.
    **Tarea a Realizar:**
    1.  Elige una red social o aplicación web compleja que uses habitualmente (ej: X, Instagram, LinkedIn, GitHub).
    2.  Abre la aplicación y navega por una de sus funcionalidades principales (ej: ver el *feed* de noticias, ver un perfil de usuario, buscar contenido).
    3.  Basándote en esa funcionalidad, describe en un breve informe (2-3 párrafos) cómo crees que se aplican los siguientes conceptos:
        *   **Capa de Presentación:** ¿Qué elementos componen la interfaz que estás viendo? (HTML, CSS, JS).
        *   **Capa de Negocio (Lógica):** ¿Qué "reglas" o procesos crees que se están ejecutando en el servidor? (ej: "algoritmo para ordenar el feed", "comprobar si sigo a este usuario").
        *   **Capa de Datos:** ¿Qué tipo de información se está guardando y recuperando de una base de datos? (ej: "lista de amigos", "publicaciones", "comentarios", "likes").
        *   **Patrón MVC (opcional si es muy complejo):** ¿Puedes imaginar qué haría un Controlador, un Modelo y una Vista en el proceso que has analizado?
    **Aplicación en el Mundo Real:** Esta habilidad para "ver la arquitectura" detrás de una aplicación es lo que diferencia a un programador junior de uno senior. Permite entender sistemas complejos rápidamente, proponer mejoras y aprender de las soluciones que otros han construido a gran escala.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>
    
    **Ejemplo de Análisis para la funcionalidad "Ver mi Feed de LinkedIn":**

    Al cargar mi feed de LinkedIn, la arquitectura subyacente podría funcionar así. La **Capa de Presentación** es todo lo que veo en mi navegador: la barra de navegación azul, la estructura de columnas, las tarjetas para cada publicación con sus botones de "Recomendar" y "Comentar", y el scroll infinito. Todo esto está construido con HTML para la estructura, CSS para los estilos y JavaScript para la interactividad (como cargar más posts sin recargar la página).

    En el servidor, la **Capa de Negocio** (el backend) es la que realiza el trabajo pesado. Al solicitar mi feed, un "Controlador" recibe mi petición. Este ejecuta la lógica de negocio, que es muy compleja: le pide a un "Modelo" las últimas publicaciones de mis contactos, de las empresas que sigo y quizás contenido patrocinado. Luego, un algoritmo de relevancia ordena todo ese contenido para decidir qué mostrarme primero. Además, comprueba mis permisos, mi nombre y mi foto de perfil para personalizar la cabecera.

    Finalmente, todo esto depende de la **Capa de Datos**. El "Modelo" interactúa con una gigantesca base de datos que almacena perfiles de usuario, las conexiones entre ellos, el contenido de cada publicación, los comentarios, las recomendaciones (`likes`), etc. La capa de negocio solicita "dame las últimas 50 publicaciones relevantes para el usuario X", y la capa de datos se encarga de realizar esa consulta de forma eficiente y devolver la información estructurada para que la capa de negocio pueda procesarla y enviarla a la capa de presentación.
    </details>

## Ejercicios de Refuerzo

Ahora que los cimientos están puestos, vamos a construir nuestros primeros módulos para la intranet "Nexus". Estos ejercicios te guiarán paso a paso.

!!! warning "Ejercicio de Refuerzo | Dificultad: Media"
    #### 7. Módulo de Noticias: Construyendo la Vista
    **Objetivo:** Crear la capa de presentación (Vista) para un componente dinámico, conectándola con datos proporcionados por el backend.
    **Setup Inicial:**
    1.  Crea un fichero llamado `noticias.php` en tu proyecto.
    2.  Pega el siguiente código al principio del fichero. Este código simula ser nuestro **Controlador** y **Modelo**, que ya han hecho su trabajo de obtener las noticias. Tu tarea es construir la parte de la **Vista**.
    ```php
    <?php
    // --- SIMULACIÓN DEL CONTROLADOR Y MODELO ---
    // En un sistema MVC real, esto estaría en ficheros separados.
    
    // El "Modelo" obtiene los datos (simulados en un array)
    function obtener_noticias() {
        return [
            [
                'titulo' => 'Lanzamiento de la nueva versión de Innovatec OS',
                'fecha' => '2025-07-22',
                'autor' => 'Equipo de Producto'
            ],
            [
                'titulo' => 'Resultados del Q2: Crecimiento récord',
                'fecha' => '2025-07-20',
                'autor' => 'Departamento Financiero'
            ],
            [
                'titulo' => 'Próximo evento: Barbacoa de verano',
                'fecha' => '2025-07-18',
                'autor' => 'Recursos Humanos'
            ]
        ];
    }
    
    // El "Controlador" llama al modelo y prepara los datos para la vista.
    $lista_noticias = obtener_noticias();
    
    // --- FIN DE LA SIMULACIÓN DEL BACKEND ---
    
    // AHORA EMPIEZA TU TRABAJO: LA VISTA
    ?>
    ```
    **Tarea a Realizar:**
    1.  Justo debajo del código PHP proporcionado, escribe la estructura HTML de la página de noticias.
    2.  Debe tener un título `<h1>` que diga "Últimas Noticias de Innovatech".
    3.  Debajo del título, crea una sección para mostrar las noticias.
    4.  Utiliza un bucle `foreach` de PHP para iterar sobre la variable `$lista_noticias`.
    5.  Dentro del bucle, por cada noticia, debes imprimir en HTML:
        *   Un encabezado `<h2>` con el título de la noticia.
        *   Un párrafo `<p>` que contenga la fecha y el autor. Por ejemplo: "Publicado el 2025-07-22 por Equipo de Producto".
    **Pista:** Dentro del bucle `foreach ($lista_noticias as $noticia)`, cada `$noticia` será un array asociativo. Podrás acceder a sus valores con `$noticia['titulo']`, `$noticia['fecha']`, etc.
    **Aplicación en el Mundo Real:** Esta es la tarea más común de un desarrollador que trabaja con un CMS o un framework: recibir un conjunto de datos del backend y maquetarlos en una plantilla (la Vista) para que el usuario final los vea formateados y ordenados.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>
    
    ```html+php
    <?php
    // --- SIMULACIÓN DEL CONTROLADOR Y MODELO ---
    // En un sistema MVC real, esto estaría en ficheros separados.
    
    // El "Modelo" obtiene los datos (simulados en un array)
    function obtener_noticias() {
        return [
            [
                'titulo' => 'Lanzamiento de la nueva versión de Innovatec OS',
                'fecha' => '2025-07-22',
                'autor' => 'Equipo de Producto'
            ],
            [
                'titulo' => 'Resultados del Q2: Crecimiento récord',
                'fecha' => '2025-07-20',
                'autor' => 'Departamento Financiero'
            ],
            [
                'titulo' => 'Próximo evento: Barbacoa de verano',
                'fecha' => '2025-07-18',
                'autor' => 'Recursos Humanos'
            ]
        ];
    }
    
    // El "Controlador" llama al modelo y prepara los datos para la vista.
    $lista_noticias = obtener_noticias();
    
    // --- FIN DE LA SIMULACIÓN DEL BACKEND ---
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Noticias - Nexus</title>
    </head>
    <body>
        <h1>Últimas Noticias de Innovatech</h1>

        <?php foreach ($lista_noticias as $noticia): ?>
            <article>
                <h2><?php echo htmlspecialchars($noticia['titulo']); ?></h2>
                <p>
                    Publicado el <?php echo htmlspecialchars($noticia['fecha']); ?> 
                    por <strong><?php echo htmlspecialchars($noticia['autor']); ?></strong>
                </p>
            </article>
            <hr>
        <?php endforeach; ?>

    </body>
    </html>
    ```
    *Nota: Se ha añadido `htmlspecialchars()` como buena práctica de seguridad para prevenir ataques XSS, aunque no se pedía explícitamente en el ejercicio.*
    </details>

!!! warning "Ejercicio de Refuerzo | Dificultad: Media"
    #### 8. Diseñando la Arquitectura del Blog Interno
    **Objetivo:** Practicar el diseño de una arquitectura de 3 capas para una nueva funcionalidad, separando mentalmente las responsabilidades antes de escribir código.
    **Tarea a Realizar:**
    El equipo de producto quiere añadir un blog a la intranet Nexus. Antes de programar, debemos diseñar su arquitectura. Responde a las siguientes preguntas para definir cómo se estructuraría esta nueva funcionalidad siguiendo el modelo de 3 capas.
    1.  **Capa de Presentación (Frontend):**
        *   ¿Qué vería el usuario? Describe al menos dos "pantallas" o vistas diferentes para el blog (ej: lista de posts, detalle de un post).
        *   ¿Qué acciones podría realizar el usuario en esta capa? (ej: hacer clic en un título, escribir un comentario).
    2.  **Capa de Negocio (Backend/Lógica):**
        *   Cuando un usuario carga la lista de posts, ¿qué "reglas de negocio" debería aplicar el servidor? (ej: ¿cuántos posts mostrar por página? ¿en qué orden?).
        *   Cuando un usuario envía un comentario, ¿qué validaciones debería realizar esta capa antes de guardarlo? (ej: comprobar que el texto no esté vacío, que el usuario tenga permiso para comentar).
    3.  **Capa de Datos (Backend/Persistencia):**
        *   ¿Qué información principal necesitaríamos almacenar en la base de datos para que el blog funcione? Piensa en al menos 3 "tablas" o entidades distintas y qué columnas tendrían.
    **Pista:** Para la capa de datos, piensa en las piezas de información: necesitamos *posts*, *usuarios* (autores) y *comentarios*. ¿Cómo se relacionarían entre sí?
    **Aplicación en el Mundo Real:** La fase de diseño de la arquitectura es crítica en proyectos de software. Tomar estas decisiones antes de escribir la primera línea de código ahorra incontables horas de trabajo y previene problemas estructurales a largo plazo. Es un paso que siempre realizan los arquitectos de software y desarrolladores senior.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>
    
    **Diseño de Arquitectura para el Blog de Nexus:**

    1.  **Capa de Presentación (Frontend):**
        *   **Vistas:**
            *   `Vista de Lista de Posts`: Mostraría un listado con el título, un extracto, el autor y la fecha de cada post. Incluiría un sistema de paginación si hay muchos posts.
            *   `Vista de Detalle de Post`: Mostraría el contenido completo de un único post, su autor, fecha, y debajo, una sección para ver los comentarios existentes y un formulario para añadir un nuevo comentario.
        *   **Acciones del Usuario:** Hacer clic en un título para navegar al detalle, hacer clic en "página siguiente", rellenar y enviar el formulario de comentarios.

    2.  **Capa de Negocio (Backend/Lógica):**
        *   **Lógica para la lista de posts:** La capa de negocio recibiría la petición, y aplicaría reglas como: "mostrar los 10 posts más recientes primero", "excluir posts que están en borrador", "obtener el nombre del autor a partir de su ID".
        *   **Lógica para enviar un comentario:** La capa de negocio recibiría los datos del formulario. Validaría que el campo de texto no esté vacío, que no exceda un número máximo de caracteres, y comprobaría que el usuario que lo envía ha iniciado sesión en la intranet. Si todo es correcto, le pasaría los datos a la capa de datos para que lo guarde. Si no, devolvería un mensaje de error.

    3.  **Capa de Datos (Backend/Persistencia):**
        *   **Tabla `posts`:** Almacenaría la información de cada artículo.
            *   Columnas: `id` (clave primaria), `titulo`, `contenido`, `fecha_publicacion`, `id_autor` (clave foránea a la tabla `usuarios`), `estado` (ej: 'publicado', 'borrador').
        *   **Tabla `usuarios`:** La tabla de empleados de la empresa, que también son los autores.
            *   Columnas: `id` (clave primaria), `nombre`, `email`, `puesto`.
        *   **Tabla `comentarios`:** Almacenaría los comentarios de cada post.
            *   Columnas: `id` (clave primaria), `texto_comentario`, `fecha`, `id_post` (clave foránea a `posts`), `id_usuario` (clave foránea a `usuarios`).
    </details>

!!! warning "Ejercicio de Refuerzo | Dificultad: Media"
    #### 9. Módulo de Directorio: El Controlador es la Clave
    **Objetivo:** Escribir la lógica de un Controlador que conecta un Modelo (datos) con una Vista (presentación), asumiendo el rol de intermediario.
    **Setup Inicial:**
    1.  Crea una carpeta `directorio-mvc` dentro de tu proyecto.
    2.  Dentro, crea tres ficheros: `modelo.php`, `vista.php` y `controlador.php`.
    3.  En `modelo.php`, pega este código (simula el acceso a datos):
        ```php
        <?php // modelo.php
        function get_todos_los_empleados() {
            // Simula una consulta a la BBDD
            return [
                ['id' => 1, 'nombre' => 'Elena Navarro', 'puesto' => 'Lead Backend Engineer'],
                ['id' => 2, 'nombre' => 'David Chen', 'puesto' => 'Frontend Developer'],
                ['id' => 3, 'nombre' => 'Fatima Zahra', 'puesto' => 'QA Specialist']
            ];
        }
        ```
    4.  En `vista.php`, pega este código (la plantilla de presentación):
        ```php
        <?php // vista.php ?>
        <!DOCTYPE html>
        <html lang="es">
        <head><title>Directorio - Vista</title></head>
        <body>
            <h1>Directorio de Empleados de Innovatech</h1>
            <table border="1">
                <tr><th>Nombre</th><th>Puesto</th></tr>
                <?php foreach ($empleados as $empleado): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($empleado['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($empleado['puesto']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </body>
        </html>
        ```
    **Tarea a Realizar:**
    1.  Tu trabajo es escribir el código del fichero `controlador.php`.
    2.  Este script debe actuar como el "director de orquesta":
        *   Primero, debe incluir (con `require_once`) el fichero `modelo.php` para poder usar sus funciones.
        *   Luego, debe llamar a la función `get_todos_los_empleados()` para obtener la lista de empleados y guardarla en una variable (por ejemplo, `$empleados`).
        *   Finalmente, debe incluir (`require_once`) el fichero `vista.php`. La vista usará automáticamente la variable `$empleados` que has creado.
    3.  Para probarlo, accede en tu navegador únicamente a `controlador.php`. Si todo está bien, deberías ver la tabla HTML completa con los datos de los empleados.
    **Pista:** El controlador es el pegamento. No calcula ni muestra nada, solo da órdenes: "Modelo, dame los datos" y "Vista, muestra estos datos".
    **Aplicación en el Mundo Real:** Esta estructura (un punto de entrada como el controlador que carga dependencias, obtiene datos y renderiza una vista) es el corazón de cómo funcionan los frameworks MVC como Laravel, Symfony o CodeIgniter. Entender este flujo es fundamental para trabajar con ellos.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>
    
    ```php
    <?php // controlador.php

    // 1. Incluir el modelo para tener acceso a los datos
    require_once 'modelo.php';
    
    // 2. Obtener los datos llamando a la función del modelo
    // La capa de negocio/controlador gestiona la lógica de la aplicación.
    $empleados = get_todos_los_empleados();
    
    // 3. Incluir la vista para renderizar la página
    // La vista recibirá la variable $empleados y la usará para mostrar los datos.
    require_once 'vista.php';
    ```
    </details>

## Ejercicios de Ampliación

Es hora de afrontar retos más complejos y abiertos. Estos ejercicios requieren iniciativa, investigación y la aplicación de los conceptos en escenarios más realistas, culminando en la revisión de vuestro propio trabajo.

!!! danger "Ejercicio de Ampliación | Dificultad: Alta"
    #### 10. Refactorizando a MVC: El Módulo de Eventos
    **Objetivo:** Reestructurar ("refactorizar") un script con "código espagueti" a una arquitectura MVC limpia, demostrando la habilidad para mejorar código existente.
    **Setup Inicial:**
    1.  Crea un fichero llamado `eventos_legacy.php`.
    2.  Pega el siguiente código "legacy" (heredado y desordenado):
    ```php
    <?php
    // eventos_legacy.php - ¡CÓDIGO ESPAGUETI!
    
    // Conexión a BBDD (simulada) y obtención de datos
    $eventos_raw = [
        ['id' => 10, 'nombre' => 'Hackathon Interno', 'fecha' => '2025-08-15', 'plazas' => 50, 'inscritos' => 48],
        ['id' => 11, 'nombre' => 'Charla: Novedades en PHP 8.4', 'fecha' => '2025-08-22', 'plazas' => 100, 'inscritos' => 95],
        ['id' => 12, 'nombre' => 'Taller de Docker', 'fecha' => '2025-09-01', 'plazas' => 20, 'inscritos' => 20],
    ];
    
    // Lógica de negocio: calcular plazas disponibles y añadir un estado
    $eventos_procesados = [];
    foreach ($eventos_raw as $evento) {
        $evento['plazas_disponibles'] = $evento['plazas'] - $evento['inscritos'];
        if ($evento['plazas_disponibles'] <= 0) {
            $evento['estado'] = 'Completo';
        } elseif ($evento['plazas_disponibles'] < 10) {
            $evento['estado'] = 'Últimas plazas';
        } else {
            $evento['estado'] = 'Disponible';
        }
        $eventos_procesados[] = $evento;
    }
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head><title>Eventos Corporativos</title></head>
    <body>
        <h1>Próximos Eventos en Innovatech</h1>
        <?php foreach ($eventos_procesados as $evento): ?>
            <div style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px;">
                <h2><?php echo htmlspecialchars($evento['nombre']); ?></h2>
                <p>Fecha: <?php echo $evento['fecha']; ?></p>
                <p><strong>Estado: <?php echo htmlspecialchars($evento['estado']); ?></strong></p>
                <p>Plazas disponibles: <?php echo $evento['plazas_disponibles']; ?></p>
            </div>
        <?php endforeach; ?>
    </body>
    </html>
    ```    **Tarea a Realizar:**
    1.  Crea una nueva estructura de ficheros para una implementación MVC. Como mínimo, necesitarás un `modelo.php`, una `vista.php` y un `controlador.php`.
    2.  **Refactoriza el código:** Mueve las responsabilidades del fichero `eventos_legacy.php` a su lugar correspondiente en la nueva estructura:
        *   **Modelo:** Debe tener una función que devuelva los datos crudos de los eventos (el array `$eventos_raw`).
        *   **Controlador:** Debe:
            *   Llamar al Modelo para obtener los eventos.
            *   Contener la lógica de negocio (el bucle que calcula las plazas disponibles y el estado).
            *   Pasar los datos ya procesados a la Vista.
        *   **Vista:** Debe contener únicamente el HTML y el bucle de presentación que recorre los datos procesados que le pasa el Controlador. Debe ser "tonta", sin cálculos.
    3.  El punto de entrada para ver el resultado debe ser tu `controlador.php`, y el resultado visual debe ser idéntico al del script original.
    **Aplicación en el Mundo Real:** La refactorización es una tarea constante en el desarrollo de software. Las empresas tienen sistemas antiguos ("legacy") que necesitan ser modernizados para que sean más fáciles de mantener, probar y escalar. Saber cómo desenredar "código espagueti" y ordenarlo en una arquitectura limpia es una habilidad muy valorada.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    **`modelo.php`**
    ```php
    <?php // modelo.php
    class EventoModel {
        public function getEventosDesdeBD() {
            // Simula la obtención de datos crudos desde la base de datos.
            return [
                ['id' => 10, 'nombre' => 'Hackathon Interno', 'fecha' => '2025-08-15', 'plazas' => 50, 'inscritos' => 48],
                ['id' => 11, 'nombre' => 'Charla: Novedades en PHP 8.4', 'fecha' => '2025-08-22', 'plazas' => 100, 'inscritos' => 95],
                ['id' => 12, 'nombre' => 'Taller de Docker', 'fecha' => '2025-09-01', 'plazas' => 20, 'inscritos' => 20],
            ];
        }
    }
    ```

    **`controlador.php`**
    ```php
    <?php // controlador.php
    require_once 'modelo.php';
    
    class EventoController {
        private $modelo;
    
        public function __construct() {
            $this->modelo = new EventoModel();
        }
    
        public function listarEventos() {
            // 1. Obtener datos crudos del Modelo
            $eventos_raw = $this->modelo->getEventosDesdeBD();
    
            // 2. Aplicar lógica de negocio
            $eventos_procesados = [];
            foreach ($eventos_raw as $evento) {
                $evento['plazas_disponibles'] = $evento['plazas'] - $evento['inscritos'];
                if ($evento['plazas_disponibles'] <= 0) {
                    $evento['estado'] = 'Completo';
                } elseif ($evento['plazas_disponibles'] < 10) {
                    $evento['estado'] = 'Últimas plazas';
                } else {
                    $evento['estado'] = 'Disponible';
                }
                $eventos_procesados[] = $evento;
            }
            
            // 3. Pasar los datos procesados a la Vista
            // La variable $eventos estará disponible en la vista.
            $eventos = $eventos_procesados;
            require 'vista.php';
        }
    }
    
    // Punto de entrada
    $controlador = new EventoController();
    $controlador->listarEventos();
    ```

    **`vista.php`**
    ```php
    <?php // vista.php ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Eventos Corporativos</title>
    </head>
    <body>
        <h1>Próximos Eventos en Innovatech</h1>
        <?php foreach ($eventos as $evento): ?>
            <div style="border: 1px solid #ccc; margin-bottom: 10px; padding: 10px;">
                <h2><?php echo htmlspecialchars($evento['nombre']); ?></h2>
                <p>Fecha: <?php echo $evento['fecha']; ?></p>
                <p><strong>Estado: <?php echo htmlspecialchars($evento['estado']); ?></strong></p>
                <p>Plazas disponibles: <?php echo $evento['plazas_disponibles']; ?></p>
            </div>
        <?php endforeach; ?>
    </body>
    </html>
    ```
    </details>

!!! danger "Ejercicio de Ampliación | Dificultad: Alta"
    #### 11. Arquitecturas Modernas: ¿Hay vida más allá de las 3 capas?
    **Objetivo:** Investigar arquitecturas de software modernas y analizar críticamente sus ventajas y desventajas en comparación con el modelo tradicional de 3 capas, aplicando el razonamiento a un caso de uso concreto.
    **Tarea a Realizar:**
    1.  **Investiga** sobre una de las siguientes arquitecturas de software:
        *   **Microservicios:** ¿En qué consiste? ¿Cuál es su filosofía?
        *   **Serverless (o FaaS - Functions as a Service):** ¿Qué significa? ¿Quién gestiona los servidores?
        *   **Jamstack:** ¿Qué significan las siglas JAM (JavaScript, APIs, Markup)? ¿Cómo se diferencia de una web dinámica tradicional?
    2.  **Prepara un informe comparativo** (de unas 300-400 palabras) que responda a estas preguntas:
        *   Describe brevemente la arquitectura que has investigado.
        *   Compara esta arquitectura con el modelo monolítico de 3 capas que hemos estudiado. ¿Cuáles son las 2 ventajas principales y los 2 inconvenientes más importantes de la arquitectura que has elegido?
        *   **Análisis Crítico:** ¿Sería una buena idea desarrollar la intranet "Nexus" con esta arquitectura en lugar de la de 3 capas? ¿O sería excesivo? Justifica tu respuesta considerando que Innovatech es una empresa mediana en crecimiento.
    **Aplicación en el Mundo Real:** El mundo de la tecnología evoluciona constantemente. Un buen arquitecto de software no solo conoce los patrones establecidos, sino que está al día de las nuevas tendencias y es capaz de decidir qué arquitectura es la más adecuada para cada proyecto, sopesando costes, escalabilidad, y la experiencia del equipo de desarrollo.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    **Ejemplo de Informe Comparativo sobre Microservicios:**

    La arquitectura de **microservicios** es un enfoque para desarrollar una única aplicación como un conjunto de pequeños servicios, cada uno ejecutándose en su propio proceso y comunicándose a través de mecanismos ligeros, a menudo una API de HTTP. Cada servicio está construido en torno a una capacidad de negocio (ej: servicio de autenticación, servicio de notificaciones, servicio de perfiles de usuario).

    En comparación con la arquitectura **monolítica de 3 capas**, donde toda la lógica de negocio reside en una única base de código, los microservicios ofrecen ventajas y desventajas claras.
    *   **Ventaja 1: Escalabilidad Independiente.** Se puede escalar solo el servicio que lo necesite. Si el servicio de noticias de Nexus recibe mucho tráfico, podemos desplegar más instancias de ese servicio sin tocar el resto de la intranet.
    *   **Ventaja 2: Autonomía Tecnológica.** Cada servicio puede estar escrito en un lenguaje de programación diferente (ej: el servicio de perfiles en PHP, un servicio de procesamiento de vídeo en Python). Esto permite usar la mejor herramienta para cada tarea.
    *   **Inconveniente 1: Complejidad Operacional.** Gestionar, desplegar y monitorizar docenas de servicios es mucho más complejo que un único monolito. La comunicación entre servicios introduce latencia y puntos de fallo.
    *   **Inconveniente 2: Consistencia de Datos.** Mantener la consistencia de los datos a través de diferentes bases de datos (una por servicio) es un desafío significativo (consistencia eventual).

    **Análisis para Nexus:** Para la intranet de una empresa mediana como Innovatech, adoptar una arquitectura de microservicios desde el principio sería, probablemente, **excesivo y contraproducente**. La complejidad operacional adicional superaría los beneficios. Un monolito bien estructurado (como el que estamos diseñando con 3 capas y MVC) es mucho más rápido de desarrollar y más fácil de mantener para un equipo pequeño. Podríamos, sin embargo, considerar extraer una funcionalidad a un microservicio en el futuro si esta crece de forma desproporcionada y requiere una escalabilidad o tecnología muy específicas. Por ahora, el monolito es la opción más pragmática.
    </details>

!!! danger "Ejercicio de Ampliación | Dificultad: Alta"
    #### 12. Reto Final y Peer Review: La API REST del Directorio
    **Objetivo:** Crear un *endpoint* de API que devuelva datos en formato JSON, sentando las bases para que otras aplicaciones (ej: una app móvil de la empresa) puedan consumir datos de la intranet.
    **Setup Inicial:**
    1.  Vas a trabajar sobre la estructura MVC del ejercicio de refuerzo nº 9 (`directorio-mvc`).
    2.  Necesitarás una herramienta para probar APIs, como **Postman**, **Insomnia**, o la propia herramienta de desarrollo de tu navegador.
    **Tarea a Realizar:**
    1.  Crea un nuevo fichero `api.php` en la raíz de `directorio-mvc`. Este será tu *endpoint*.
    2.  En `api.php`, implementa la lógica de un **Controlador** que:
        *   Incluya el `modelo.php`.
        *   Llame a la función `get_todos_los_empleados()` para obtener los datos.
        *   **NO** incluya una vista HTML.
        *   En su lugar, debe establecer la cabecera HTTP correcta para indicar que la respuesta es JSON. Usa esta línea de código: `header('Content-Type: application/json');`
        *   Finalmente, debe convertir el array de PHP a formato JSON y mostrarlo. Usa la función `json_encode()`: `echo json_encode($datos);`
    3.  Accede a `http://localhost/.../directorio-mvc/api.php` en tu navegador o Postman. El resultado no debe ser una página web, sino un texto plano con la estructura JSON que representa a los empleados.

    ---
    **Tarea de Revisión por Pares (Peer Review):**
    1.  Intercambia tu `api.php` (o la URL de tu endpoint si lo has subido a algún sitio) con un compañero.
    2.  Actúa como el "cliente" de la API de tu compañero. Usa Postman para hacer una petición `GET` a su endpoint.
    3.  **Verifica y da feedback** sobre los siguientes puntos:
        *   ¿La respuesta tiene el `Content-Type` correcto (`application/json`)? (Puedes verlo en la pestaña "Headers" de Postman).
        *   ¿El cuerpo (body) de la respuesta es un JSON válido? (Postman te lo indicará si puede formatearlo).
        *   ¿La estructura de datos en el JSON es la que esperabas?
        *   Revisa su código `api.php`. ¿Es limpio? ¿Sigue la lógica de un controlador (obtener datos y devolverlos, sin HTML ni lógica extra)?
    
    **Aplicación en el Mundo Real:** Las APIs son el tejido conectivo de la web moderna. Permiten que tu aplicación frontend (hecha en React, Vue, Angular) o una app móvil se comuniquen con tu backend. Crear endpoints de API eficientes y bien estructurados es una de las tareas más comunes y demandadas para un desarrollador backend.
    <details>
    <summary>Haz clic aquí para ver una posible solución</summary>

    **Contenido del fichero `api.php`:**

    ```php
    <?php // api.php

    // Incluir el modelo para tener acceso a la función que obtiene los datos.
    require_once 'modelo.php';
    
    // --- Lógica del Controlador de API ---
    
    // Obtener los datos desde el modelo.
    $empleados = get_todos_los_empleados();
    
    // Establecer la cabecera para indicar que la respuesta será en formato JSON.
    // Esto es crucial para que los clientes (como un framework de JavaScript o Postman)
    // interpreten la respuesta correctamente.
    header('Content-Type: application/json');
    
    // Codificar el array de PHP a una cadena de texto en formato JSON y enviarlo como respuesta.
    echo json_encode($empleados, JSON_PRETTY_PRINT); // JSON_PRETTY_PRINT es opcional, pero hace la salida más legible para humanos.
    
    ```

    **Resultado esperado al acceder a `api.php`:**

    ```json
    [
        {
            "id": 1,
            "nombre": "Elena Navarro",
            "puesto": "Lead Backend Engineer"
        },
        {
            "id": 2,
            "nombre": "David Chen",
            "puesto": "Frontend Developer"
        },
        {
            "id": 3,
            "nombre": "Fatima Zahra",
            "puesto": "QA Specialist"
        }
    ]
    ```
    </details>